import { AIMessage, HumanMessage, ToolMessage } from '@langchain/core/messages';
import type { CallbackManagerForLLMRun } from '@langchain/core/callbacks/manager';
import type { ChatGenerationChunk } from '@langchain/core/outputs';
import type { BaseMessage } from '@langchain/core/messages';
import type { OpenAIClient } from '@langchain/openai';

import { ChatDeepSeek } from './index';

type DeepSeekRequest =
  | OpenAIClient.Chat.ChatCompletionCreateParamsStreaming
  | OpenAIClient.Chat.ChatCompletionCreateParamsNonStreaming;
type OpenAIChatCompletion = OpenAIClient.Chat.Completions.ChatCompletion;
type OpenAIChatCompletionChunk =
  OpenAIClient.Chat.Completions.ChatCompletionChunk;
type PromptTokensDetailsWithCacheWrite = NonNullable<
  OpenAIClient.Completions.CompletionUsage['prompt_tokens_details']
> & {
  cache_write_tokens?: number;
};
type CompletionUsageWithCacheWrite = Omit<
  OpenAIClient.Completions.CompletionUsage,
  'prompt_tokens_details'
> & {
  prompt_tokens_details?: PromptTokensDetailsWithCacheWrite;
};
type ReasoningAssistantMessageParam =
  OpenAIClient.Chat.Completions.ChatCompletionAssistantMessageParam & {
    reasoning_content?: string;
  };

class CapturingChatDeepSeek extends ChatDeepSeek {
  readonly requests: DeepSeekRequest[] = [];

  constructor(
    fields: ConstructorParameters<typeof ChatDeepSeek>[0],
    private readonly streamChunks = createCompletionStreamChunks(),
    private readonly completion = createCompletion()
  ) {
    super(fields);
  }

  async completionWithRetry(
    request: OpenAIClient.Chat.ChatCompletionCreateParamsStreaming,
    requestOptions?: OpenAIClient.RequestOptions
  ): Promise<AsyncIterable<OpenAIChatCompletionChunk>>;
  async completionWithRetry(
    request: OpenAIClient.Chat.ChatCompletionCreateParamsNonStreaming,
    requestOptions?: OpenAIClient.RequestOptions
  ): Promise<OpenAIChatCompletion>;
  async completionWithRetry(
    request: DeepSeekRequest,
    _requestOptions?: OpenAIClient.RequestOptions
  ): Promise<AsyncIterable<OpenAIChatCompletionChunk> | OpenAIChatCompletion> {
    this.requests.push(request);

    if (request.stream === true) {
      return createCompletionStream(this.streamChunks);
    }

    return this.completion;
  }

  streamChunksWithSignal(
    signal: AbortSignal
  ): AsyncGenerator<ChatGenerationChunk> {
    return this._streamResponseChunks([new HumanMessage('hi')], {
      signal,
    } as this['ParsedCallOptions']);
  }

  streamChunksWithCallbacks(
    runManager?: CallbackManagerForLLMRun
  ): AsyncGenerator<ChatGenerationChunk> {
    return this._streamResponseChunks(
      [new HumanMessage('hi')],
      {} as this['ParsedCallOptions'],
      runManager
    );
  }
}

function createToolContextMessages(): BaseMessage[] {
  return [
    new AIMessage({
      content: '',
      tool_calls: [
        {
          id: 'call_1',
          name: 'web_search',
          args: { query: 'trending news today' },
          type: 'tool_call',
        },
      ],
      additional_kwargs: {
        reasoning_content: 'Need current news from the web.',
      },
    }),
    new ToolMessage({
      content: 'Search results',
      tool_call_id: 'call_1',
    }),
  ];
}

function createCompletionStreamChunks(): OpenAIChatCompletionChunk[] {
  return [
    createContentChunk('ok'),
    {
      id: 'chatcmpl-deepseek-test',
      object: 'chat.completion.chunk',
      created: 0,
      model: 'deepseek-v4-pro',
      choices: [
        {
          index: 0,
          delta: {},
          finish_reason: 'stop',
          logprobs: null,
        },
      ],
    },
  ];
}

function createContentChunk(
  content: string,
  logprobs: OpenAIChatCompletionChunk['choices'][number]['logprobs'] = null
): OpenAIChatCompletionChunk {
  return {
    id: 'chatcmpl-deepseek-test',
    object: 'chat.completion.chunk',
    created: 0,
    model: 'deepseek-v4-pro',
    choices: [
      {
        index: 0,
        delta: {
          role: 'assistant',
          content,
        },
        finish_reason: null,
        logprobs,
      },
    ],
  };
}

async function* createCompletionStream(
  chunks: OpenAIChatCompletionChunk[]
): AsyncGenerator<OpenAIChatCompletionChunk> {
  for (const chunk of chunks) {
    yield chunk;
  }
}

function createCompletion(
  usage: CompletionUsageWithCacheWrite = {
    prompt_tokens: 1,
    completion_tokens: 1,
    total_tokens: 2,
  }
): OpenAIChatCompletion {
  return {
    id: 'chatcmpl-deepseek-test',
    object: 'chat.completion',
    created: 0,
    model: 'deepseek-v4-pro',
    choices: [
      {
        index: 0,
        message: {
          role: 'assistant',
          content: 'ok',
          refusal: null,
        },
        finish_reason: 'stop',
        logprobs: null,
      },
    ],
    usage,
  };
}

function getReasoningAssistantMessage(
  request: DeepSeekRequest
): ReasoningAssistantMessageParam {
  return request.messages[0] as ReasoningAssistantMessageParam;
}

async function drainStream(stream: AsyncIterable<unknown>): Promise<void> {
  for await (const chunk of stream) {
    void chunk;
  }
}

describe('ChatDeepSeek', () => {
  it('passes reasoning_content back on same-run streaming tool continuations', async () => {
    const model = new CapturingChatDeepSeek({
      apiKey: 'test-key',
      model: 'deepseek-v4-pro',
      streaming: true,
    });
    const chunks = [];

    for await (const chunk of await model.stream(createToolContextMessages())) {
      chunks.push(chunk);
    }

    expect(chunks).toHaveLength(2);
    expect(model.requests).toHaveLength(1);
    expect(getReasoningAssistantMessage(model.requests[0])).toEqual(
      expect.objectContaining({
        role: 'assistant',
        content: '',
        reasoning_content: 'Need current news from the web.',
      })
    );
  });

  it('passes reasoning_content back on same-run non-streaming tool continuations', async () => {
    const model = new CapturingChatDeepSeek({
      apiKey: 'test-key',
      model: 'deepseek-v4-pro',
      streaming: false,
    });

    await model.invoke(createToolContextMessages());

    expect(model.requests).toHaveLength(1);
    expect(getReasoningAssistantMessage(model.requests[0])).toEqual(
      expect.objectContaining({
        role: 'assistant',
        content: '',
        reasoning_content: 'Need current news from the web.',
      })
    );
  });

  it('keeps raw think fallback content out of streamed assistant content', async () => {
    const model = new CapturingChatDeepSeek(
      {
        apiKey: 'test-key',
        model: 'deepseek-v4-pro',
        streaming: true,
      },
      [
        createContentChunk('prefix <thi'),
        createContentChunk('nk>hidden'),
        createContentChunk('</think>visible'),
      ]
    );
    const chunks = [];
    const callbackTokens: string[] = [];

    const stream = await model.stream([new HumanMessage('hi')], {
      callbacks: [
        {
          handleLLMNewToken(token: string): void {
            callbackTokens.push(token);
          },
        },
      ],
    });

    for await (const chunk of stream) {
      chunks.push(chunk);
    }

    const streamedText = chunks
      .map((chunk) => (typeof chunk.content === 'string' ? chunk.content : ''))
      .join('');
    const hasHiddenReasoning = chunks.some(
      (chunk) => chunk.additional_kwargs.reasoning_content === 'hidden'
    );

    expect(streamedText).toBe('prefix visible');
    expect(callbackTokens.join('')).toBe('prefix visible');
    expect(callbackTokens.join('')).not.toContain('hidden');
    expect(callbackTokens.join('')).not.toContain('think');
    expect(hasHiddenReasoning).toBe(true);
  });

  it('keeps multiple raw think fallback blocks hidden from content and callbacks', async () => {
    const model = new CapturingChatDeepSeek(
      {
        apiKey: 'test-key',
        model: 'deepseek-v4-pro',
        streaming: true,
      },
      [
        createContentChunk(
          'before<think>hidden one</think>visible<think>hidden two</think>done'
        ),
      ]
    );
    const chunks = [];
    const callbackTokens: string[] = [];

    const stream = await model.stream([new HumanMessage('hi')], {
      callbacks: [
        {
          handleLLMNewToken(token: string): void {
            callbackTokens.push(token);
          },
        },
      ],
    });

    for await (const chunk of stream) {
      chunks.push(chunk);
    }

    const streamedText = chunks
      .map((chunk) => (typeof chunk.content === 'string' ? chunk.content : ''))
      .join('');
    const reasoningContent = chunks
      .map((chunk) => chunk.additional_kwargs.reasoning_content)
      .filter((content): content is string => typeof content === 'string');

    expect(streamedText).toBe('beforevisibledone');
    expect(callbackTokens.join('')).toBe('beforevisibledone');
    expect(reasoningContent).toEqual(['hidden one', 'hidden two']);
  });

  it('keeps cross-chunk multiple raw think fallback blocks hidden from content and callbacks', async () => {
    const model = new CapturingChatDeepSeek(
      {
        apiKey: 'test-key',
        model: 'deepseek-v4-pro',
        streaming: true,
      },
      [
        createContentChunk('before<think>hidden one</thi'),
        createContentChunk('nk>visible<thi'),
        createContentChunk('nk>hidden two</think>done'),
      ]
    );
    const chunks = [];
    const callbackTokens: string[] = [];

    const stream = await model.stream([new HumanMessage('hi')], {
      callbacks: [
        {
          handleLLMNewToken(token: string): void {
            callbackTokens.push(token);
          },
        },
      ],
    });

    for await (const chunk of stream) {
      chunks.push(chunk);
    }

    const streamedText = chunks
      .map((chunk) => (typeof chunk.content === 'string' ? chunk.content : ''))
      .join('');
    const reasoningContent = chunks
      .map((chunk) => chunk.additional_kwargs.reasoning_content)
      .filter((content): content is string => typeof content === 'string');

    expect(streamedText).toBe('beforevisibledone');
    expect(callbackTokens.join('')).toBe('beforevisibledone');
    expect(reasoningContent).toEqual(['hidden one', 'hidden two']);
  });

  it('emits trailing unfinished raw think fallback as reasoning content', async () => {
    const model = new CapturingChatDeepSeek(
      {
        apiKey: 'test-key',
        model: 'deepseek-v4-pro',
        streaming: true,
      },
      [createContentChunk('<think>truncated')]
    );
    const chunks = [];
    const callbackTokens: string[] = [];

    const stream = await model.stream([new HumanMessage('hi')], {
      callbacks: [
        {
          handleLLMNewToken(token: string): void {
            callbackTokens.push(token);
          },
        },
      ],
    });

    for await (const chunk of stream) {
      chunks.push(chunk);
    }

    const streamedText = chunks
      .map((chunk) => (typeof chunk.content === 'string' ? chunk.content : ''))
      .join('');
    const reasoningContent = chunks
      .map((chunk) => chunk.additional_kwargs.reasoning_content)
      .filter((content): content is string => typeof content === 'string');

    expect(streamedText).toBe('');
    expect(callbackTokens.join('')).toBe('');
    expect(reasoningContent).toEqual(['truncated']);
  });

  it('preserves detailed usage metadata in non-streaming responses', async () => {
    const model = new CapturingChatDeepSeek(
      {
        apiKey: 'test-key',
        model: 'deepseek-v4-pro',
        streaming: false,
      },
      createCompletionStreamChunks(),
      createCompletion({
        prompt_tokens: 11,
        completion_tokens: 7,
        total_tokens: 18,
        prompt_tokens_details: {
          audio_tokens: 2,
          cached_tokens: 3,
          cache_write_tokens: 6,
        },
        completion_tokens_details: {
          audio_tokens: 4,
          reasoning_tokens: 5,
        },
      })
    );

    const response = await model.invoke([new HumanMessage('hi')]);

    expect(response.usage_metadata).toEqual({
      input_tokens: 11,
      output_tokens: 7,
      total_tokens: 18,
      input_token_details: {
        audio: 2,
        cache_read: 3,
        cache_creation: 6,
      },
      output_token_details: {
        audio: 4,
        reasoning: 5,
      },
    });
  });

  it('does not serialize non-streaming requests when aborted before generation', async () => {
    const controller = new AbortController();
    const model = new CapturingChatDeepSeek({
      apiKey: 'test-key',
      model: 'deepseek-v4-pro',
      streaming: false,
    });

    controller.abort();

    await expect(
      model.invoke([new HumanMessage('hi')], {
        signal: controller.signal,
      })
    ).rejects.toThrow();
    expect(model.requests).toHaveLength(0);
  });

  it('throws AbortError when a DeepSeek stream is canceled', async () => {
    const controller = new AbortController();
    const model = new CapturingChatDeepSeek({
      apiKey: 'test-key',
      model: 'deepseek-v4-pro',
      streaming: true,
    });

    controller.abort();

    await expect(
      drainStream(model.streamChunksWithSignal(controller.signal))
    ).rejects.toThrow('AbortError');
  });

  it('throws AbortError when a DeepSeek stream is canceled mid-stream', async () => {
    const controller = new AbortController();
    const model = new CapturingChatDeepSeek(
      {
        apiKey: 'test-key',
        model: 'deepseek-v4-pro',
        streaming: true,
      },
      [createContentChunk('first '), createContentChunk('second')]
    );
    const stream = model.streamChunksWithSignal(controller.signal);
    const iterator = stream[Symbol.asyncIterator]();

    await expect(iterator.next()).resolves.toEqual(
      expect.objectContaining({
        done: false,
        value: expect.objectContaining({
          text: 'first ',
        }),
      })
    );

    controller.abort();

    await expect(iterator.next()).rejects.toThrow('AbortError');
  });

  it('does not yield a delayed DeepSeek chunk after abort', async () => {
    const controller = new AbortController();
    const model = new CapturingChatDeepSeek(
      {
        apiKey: 'test-key',
        model: 'deepseek-v4-pro',
        streaming: true,
        _lc_stream_delay: 1000,
      },
      [createContentChunk('first '), createContentChunk('second')]
    );
    const stream = model.streamChunksWithSignal(controller.signal);
    const iterator = stream[Symbol.asyncIterator]();

    await expect(iterator.next()).resolves.toEqual(
      expect.objectContaining({
        done: false,
        value: expect.objectContaining({
          text: 'first ',
        }),
      })
    );

    const delayedChunk = iterator.next();
    await Promise.resolve();
    controller.abort(new Error('AbortError: User aborted request.'));

    await expect(delayedChunk).rejects.toThrow('AbortError');
  });

  it('splits large delayed DeepSeek text chunks', async () => {
    const model = new CapturingChatDeepSeek(
      {
        apiKey: 'test-key',
        model: 'deepseek-v4-pro',
        streaming: true,
        _lc_stream_delay: 1,
      },
      [createContentChunk('alpha beta gamma')]
    );
    const textChunks: string[] = [];

    for await (const chunk of model.streamChunksWithSignal(
      new AbortController().signal
    )) {
      if (chunk.text) {
        textChunks.push(chunk.text);
      }
    }

    expect(textChunks).toEqual(['alpha ', 'beta ', 'gamma']);
  });

  it('does not delay tool-call and finish chunks between paced text', async () => {
    const toolCallChunk: OpenAIChatCompletionChunk = {
      id: 'chatcmpl-deepseek-test',
      object: 'chat.completion.chunk',
      created: 0,
      model: 'deepseek-v4-pro',
      choices: [
        {
          index: 0,
          delta: {
            role: 'assistant',
            tool_calls: [
              {
                index: 0,
                id: 'call_1',
                type: 'function',
                function: { name: 'lookup', arguments: '{}' },
              },
            ],
          },
          finish_reason: null,
          logprobs: null,
        },
      ],
    };
    const model = new CapturingChatDeepSeek(
      {
        apiKey: 'test-key',
        model: 'deepseek-v4-pro',
        streaming: true,
        _lc_stream_delay: 150,
      },
      [createContentChunk('alpha beta'), toolCallChunk]
    );
    const arrivals: { text: string; hasToolCall: boolean; at: number }[] = [];

    for await (const chunk of model.streamChunksWithSignal(
      new AbortController().signal
    )) {
      const message = chunk.message as Partial<AIMessage>;
      arrivals.push({
        text: chunk.text,
        hasToolCall: (message.tool_calls?.length ?? 0) > 0,
        at: Date.now(),
      });
    }

    const toolArrival = arrivals.find((entry) => entry.hasToolCall);
    const lastText = [...arrivals].reverse().find((entry) => entry.text !== '');
    expect(toolArrival).toBeDefined();
    expect(lastText).toBeDefined();
    expect(
      (toolArrival as { at: number }).at - (lastText as { at: number }).at
    ).toBeLessThan(100);
  });

  it('keeps delayed DeepSeek logprob chunks intact', async () => {
    const logprobs = { content: [], refusal: null } as NonNullable<
      OpenAIChatCompletionChunk['choices'][number]['logprobs']
    >;
    const model = new CapturingChatDeepSeek(
      {
        apiKey: 'test-key',
        model: 'deepseek-v4-pro',
        streaming: true,
        logprobs: true,
        _lc_stream_delay: 1,
      },
      [createContentChunk('alpha beta gamma', logprobs)]
    );
    const chunks: ChatGenerationChunk[] = [];

    for await (const chunk of model.streamChunksWithSignal(
      new AbortController().signal
    )) {
      if (chunk.text !== '') {
        chunks.push(chunk);
      }
    }

    expect(chunks.map((chunk) => chunk.text)).toEqual(['alpha beta gamma']);
    expect(chunks[0].generationInfo?.logprobs).toBe(logprobs);
  });

  it('emits callbacks for split delayed DeepSeek text chunks', async () => {
    const model = new CapturingChatDeepSeek(
      {
        apiKey: 'test-key',
        model: 'deepseek-v4-pro',
        streaming: true,
        _lc_stream_delay: 1,
      },
      [createContentChunk('alpha beta gamma')]
    );
    const textChunks: string[] = [];
    const callbackTokens: string[] = [];

    const stream = await model.stream([new HumanMessage('hi')], {
      callbacks: [
        {
          handleLLMNewToken(token: string): void {
            if (token !== '') {
              callbackTokens.push(token);
            }
          },
        },
      ],
    });

    for await (const chunk of stream) {
      if (typeof chunk.content === 'string' && chunk.content !== '') {
        textChunks.push(chunk.content);
      }
    }

    expect(textChunks).toEqual(['alpha ', 'beta ', 'gamma']);
    expect(callbackTokens).toEqual(textChunks);
  });

  it('emits a delayed DeepSeek callback before an early stream break', async () => {
    const model = new CapturingChatDeepSeek(
      {
        apiKey: 'test-key',
        model: 'deepseek-v4-pro',
        streaming: true,
        _lc_stream_delay: 1,
      },
      [createContentChunk('alpha beta gamma')]
    );
    const textChunks: string[] = [];
    const callbackTokens: string[] = [];
    const runManager = {
      handleLLMNewToken(token: string): void {
        if (token !== '') {
          callbackTokens.push(token);
        }
      },
    } as unknown as CallbackManagerForLLMRun;

    for await (const chunk of model.streamChunksWithCallbacks(runManager)) {
      if (chunk.text !== '') {
        textChunks.push(chunk.text);
      }
      break;
    }

    expect(textChunks).toEqual(['alpha ']);
    expect(callbackTokens).toEqual(textChunks);
  });

  it('counts consumer work toward delayed DeepSeek cadence', async () => {
    const model = new CapturingChatDeepSeek(
      {
        apiKey: 'test-key',
        model: 'deepseek-v4-pro',
        streaming: true,
        _lc_stream_delay: 100,
      },
      [createContentChunk('first '), createContentChunk('second')]
    );
    const stream = model.streamChunksWithSignal(new AbortController().signal);
    const iterator = stream[Symbol.asyncIterator]();

    await expect(iterator.next()).resolves.toEqual(
      expect.objectContaining({
        done: false,
        value: expect.objectContaining({
          text: 'first ',
        }),
      })
    );

    await new Promise<void>((resolve) => {
      setTimeout(resolve, 125);
    });
    const started = Date.now();

    await expect(iterator.next()).resolves.toEqual(
      expect.objectContaining({
        done: false,
        value: expect.objectContaining({
          text: 'second',
        }),
      })
    );
    expect(Date.now() - started).toBeLessThan(50);
  });
});

// src/hooks/HookRegistry.ts
import type {
  HookEvent,
  HookMatcher,
  ToolApprovalReplayKey,
  ToolApprovalReplaySnapshot,
  AggregatedHookResult,
} from './types';

function serializeApprovalKey(key: ToolApprovalReplayKey): string {
  return JSON.stringify([key.executionScope, key.agentId, key.toolUseId]);
}

function deserializeApprovalKey(value: string): ToolApprovalReplayKey | null {
  const parsed: unknown = JSON.parse(value);
  if (
    !Array.isArray(parsed) ||
    parsed.length !== 3 ||
    parsed.some((part) => typeof part !== 'string')
  ) {
    return null;
  }
  return {
    executionScope: parsed[0],
    agentId: parsed[1],
    toolUseId: parsed[2],
  };
}

/**
 * Internal matcher storage type.
 *
 * Matchers registered via the public `register<E>` API are strictly typed
 * to a single `E`, but the storage needs one uniform slot type per event.
 * We store them as `HookMatcher<HookEvent>` and cast once at the variance
 * boundary — see `ensureList` and `snapshot` below. The invariant (every
 * matcher in `bucket[event]` was registered with that exact event) is
 * enforced by the public API; breaking it requires bypassing the types.
 */
type MatcherBucket = Partial<Record<HookEvent, HookMatcher<HookEvent>[]>>;

/**
 * Events whose hooks can change a tool call's input or output. Presence of
 * any of these disables eager tool execution and early completion emission;
 * observation-only events (`PostToolBatch`, `Stop`, telemetry hooks) do not.
 */
const RESULT_ALTERING_HOOK_EVENTS = [
  'PreToolUse',
  'PostToolUse',
  'PostToolUseFailure',
] as const satisfies readonly HookEvent[];

/**
 * Snapshot of a halt request raised by a hook returning
 * `preventContinuation: true`. The SDK's run loop polls for this between
 * stream events and exits cleanly when set, skipping the `Stop` hook
 * (the run is being halted, not naturally completing). One per registry
 * instance — the first hook to halt wins; subsequent halts are ignored
 * so the original reason isn't clobbered.
 */
export interface HookHaltSignal {
  reason: string;
  /** Event of the hook that triggered the halt (for diagnostics). */
  source: HookEvent;
}

/**
 * Run-scoped storage for hook matchers with an additional layer for
 * session-scoped matchers that should be cleaned up between sessions.
 *
 * Hosts construct one registry per `Run` (mirroring how `HandlerRegistry` is
 * scoped) and register global matchers + per-session matchers against it.
 * Registration is strictly additive — nothing in this class mutates a
 * matcher's callbacks or flags after insertion.
 *
 * ## Why `Map<sessionId, MatcherBucket>` and not `Record`
 *
 * LibreChat runs thousands of parallel sessions in one Node process, and
 * hook registration happens inside hot paths (tool loading, agent spawning).
 * A `Record<sessionId, ...>` has to be spread on every insertion, which is
 * O(n) per call and O(n²) total for a batch of parallel registrations. A
 * Map mutates in place, keeping insertions O(1). This mirrors the reasoning
 * Claude Code documents at `utils/hooks/sessionHooks.ts:62`.
 */
export class HookRegistry {
  private readonly global: MatcherBucket = {};
  private readonly sessions: Map<string, MatcherBucket> = new Map();
  /**
   * Per-session halt signals. Scoped by `sessionId` (= the run id the
   * hook fired under) so a host that shares one registry across
   * concurrent runs cannot leak `preventContinuation` from one run
   * into another. Without scoping, a halt raised by run A's hook
   * would trip run B's stream-loop poll on the next iteration —
   * silently terminating an unrelated run.
   *
   * Map storage mirrors the reasoning above for session matchers:
   * O(1) insertion in hot paths, no spread-on-write.
   */
  private readonly haltSignals: Map<string, HookHaltSignal> = new Map();
  /** One-shot hook contributions retained until approval is consumed. */
  private readonly pendingToolApprovals = new Map<
    string,
    Map<string, AggregatedHookResult>
  >();

  /**
   * Register a matcher for the lifetime of this registry (= one Run).
   * Returns an unregister function that removes the matcher by reference.
   */
  register<E extends HookEvent>(event: E, matcher: HookMatcher<E>): () => void {
    const list = ensureList(this.global, event);
    list.push(widen(matcher));
    return () => {
      removeFromList(list, matcher);
    };
  }

  /**
   * Register a matcher for a specific session. Cleared automatically when
   * `clearSession(sessionId)` is called, or can be removed directly via the
   * returned unregister function.
   */
  registerSession<E extends HookEvent>(
    sessionId: string,
    event: E,
    matcher: HookMatcher<E>
  ): () => void {
    const bucket = this.ensureSessionBucket(sessionId);
    const list = ensureList(bucket, event);
    list.push(widen(matcher));
    return () => {
      removeFromList(list, matcher);
    };
  }

  /**
   * Returns all matchers registered for `event`, concatenating global first
   * and then session-specific (when `sessionId` is supplied). The caller
   * receives a fresh array, so iterating it is safe even if a matcher is
   * removed mid-iteration (e.g. via `once: true`).
   */
  getMatchers<E extends HookEvent>(
    event: E,
    sessionId?: string
  ): HookMatcher<E>[] {
    const globalList = readList(this.global, event);
    if (sessionId === undefined) {
      return snapshot<E>(globalList);
    }
    const bucket = this.sessions.get(sessionId);
    if (bucket === undefined) {
      return snapshot<E>(globalList);
    }
    const sessionList = readList(bucket, event);
    if (globalList.length === 0) {
      return snapshot<E>(sessionList);
    }
    if (sessionList.length === 0) {
      return snapshot<E>(globalList);
    }
    return snapshot<E>([...globalList, ...sessionList]);
  }

  /**
   * Removes `matcher` by reference from global storage first, falling back
   * to the session bucket when `sessionId` is supplied. Used by
   * `executeHooks` to drop `once: true` matchers after they fire.
   */
  removeMatcher<E extends HookEvent>(
    event: E,
    matcher: HookMatcher<E>,
    sessionId?: string
  ): boolean {
    if (removeFromList(readList(this.global, event), matcher)) {
      return true;
    }
    if (sessionId === undefined) {
      return false;
    }
    const bucket = this.sessions.get(sessionId);
    if (bucket === undefined) {
      return false;
    }
    return removeFromList(readList(bucket, event), matcher);
  }

  /**
   * Drops every session-scoped matcher for `sessionId`. Call this in the
   * `finally` block around a Run so a `once: true` hook that never fired
   * cannot leak into the next session on the same registry.
   */
  clearSession(sessionId: string): void {
    this.sessions.delete(sessionId);
    this.pendingToolApprovals.delete(sessionId);
  }

  /** Copies session-scoped policy into a rebuilt or branched Run. */
  copySession(sourceSessionId: string, targetSessionId: string): void {
    if (sourceSessionId === targetSessionId) {
      return;
    }
    const source = this.sessions.get(sourceSessionId);
    if (source != null) {
      const target = this.ensureSessionBucket(targetSessionId);
      for (const event of Object.keys(source) as HookEvent[]) {
        const targetList = ensureList(target, event);
        for (const matcher of readList(source, event)) {
          if (!targetList.includes(matcher)) {
            targetList.push(matcher);
          }
        }
      }
    }
    const pending = this.pendingToolApprovals.get(sourceSessionId);
    if (pending == null) {
      return;
    }
    let targetPending = this.pendingToolApprovals.get(targetSessionId);
    if (targetPending == null) {
      targetPending = new Map();
      this.pendingToolApprovals.set(targetSessionId, targetPending);
    }
    for (const [toolUseId, result] of pending) {
      if (!targetPending.has(toolUseId)) {
        targetPending.set(toolUseId, result);
      }
    }
  }

  getPendingToolApproval(
    sessionId: string,
    key: ToolApprovalReplayKey
  ): AggregatedHookResult | undefined {
    return this.pendingToolApprovals
      .get(sessionId)
      ?.get(serializeApprovalKey(key));
  }

  setPendingToolApproval(
    sessionId: string,
    key: ToolApprovalReplayKey,
    result: AggregatedHookResult
  ): void {
    let pending = this.pendingToolApprovals.get(sessionId);
    if (pending == null) {
      pending = new Map();
      this.pendingToolApprovals.set(sessionId, pending);
    }
    pending.set(serializeApprovalKey(key), result);
  }

  clearPendingToolApproval(
    sessionId: string,
    key: ToolApprovalReplayKey
  ): void {
    const pending = this.pendingToolApprovals.get(sessionId);
    if (pending == null) {
      return;
    }
    pending.delete(serializeApprovalKey(key));
    if (pending.size === 0) {
      this.pendingToolApprovals.delete(sessionId);
    }
  }

  snapshotPendingToolApprovals(
    sessionId: string,
    executionScope: string
  ): ToolApprovalReplaySnapshot[] {
    const pending = this.pendingToolApprovals.get(sessionId);
    if (pending == null) {
      return [];
    }
    const snapshots: ToolApprovalReplaySnapshot[] = [];
    for (const [serializedKey, result] of pending) {
      const key = deserializeApprovalKey(serializedKey);
      if (key == null || key.executionScope !== executionScope) {
        continue;
      }
      snapshots.push({ key, result });
    }
    return snapshots;
  }

  restorePendingToolApprovals(
    sessionId: string,
    targetExecutionScope: string,
    snapshots: ReadonlyArray<ToolApprovalReplaySnapshot>
  ): void {
    const restored = new Map<string, AggregatedHookResult>();
    for (const [serializedKey, result] of this.pendingToolApprovals.get(
      sessionId
    ) ?? []) {
      const key = deserializeApprovalKey(serializedKey);
      if (key?.executionScope !== targetExecutionScope) {
        restored.set(serializedKey, result);
      }
    }
    for (const snapshot of snapshots) {
      restored.set(
        serializeApprovalKey({
          ...snapshot.key,
          executionScope: targetExecutionScope,
        }),
        snapshot.result
      );
    }
    if (restored.size === 0) {
      this.pendingToolApprovals.delete(sessionId);
      return;
    }
    this.pendingToolApprovals.set(sessionId, restored);
  }

  /**
   * Raise a halt signal scoped to `sessionId` (= the run id the hook
   * fired under). The SDK's run loop polls for this between stream
   * events with the run's own id. First-write-wins per session: a
   * halt already raised by an earlier hook in the same run is
   * preserved so the original `reason` / `source` aren't overwritten.
   *
   * Per-session scoping is critical when hosts share one registry
   * across concurrent runs (e.g. a global policy registered once and
   * reused). Without it, a `preventContinuation` from run A would
   * trip run B's stream-loop poll on the next iteration and silently
   * terminate an unrelated run.
   *
   * Called by the SDK after `executeHooks` returns an aggregate with
   * `preventContinuation: true`. Hosts can also call it directly from
   * inside a hook callback if they want to halt without going through
   * the aggregated return value, but `preventContinuation` is the
   * canonical path.
   */
  haltRun(sessionId: string, reason: string, source: HookEvent): void {
    if (this.haltSignals.has(sessionId)) {
      return;
    }
    this.haltSignals.set(sessionId, { reason, source });
  }

  /**
   * Returns the halt signal raised by hooks running under `sessionId`,
   * or `undefined` if no hook in that run has halted. Polled by
   * `Run.processStream` between stream events using the run's own id.
   */
  getHaltSignal(sessionId: string): HookHaltSignal | undefined {
    return this.haltSignals.get(sessionId);
  }

  /**
   * Clears the halt signal for `sessionId`. Called by
   * `Run.processStream` in its `finally` block so a subsequent
   * invocation of the same Run (e.g. resume) starts with a fresh
   * halt state. No-op when no signal exists for that session.
   */
  clearHaltSignal(sessionId: string): void {
    this.haltSignals.delete(sessionId);
  }

  /**
   * True when any registered hook can alter a tool result before or after
   * execution (`PreToolUse`, `PostToolUse`, `PostToolUseFailure`). Eager
   * tool execution and early completion emission gate on this instead of
   * registry presence, so observation-only registries (e.g. a
   * `PostToolBatch` steering drain) keep those fast paths. With
   * `sessionId`, checks global + that session; without it, conservatively
   * scans every session bucket.
   */
  hasResultAlteringHooks(sessionId?: string): boolean {
    if (hasResultAlteringInBucket(this.global)) {
      return true;
    }
    if (sessionId !== undefined) {
      const bucket = this.sessions.get(sessionId);
      return bucket !== undefined && hasResultAlteringInBucket(bucket);
    }
    for (const bucket of this.sessions.values()) {
      if (hasResultAlteringInBucket(bucket)) {
        return true;
      }
    }
    return false;
  }

  /** True if at least one matcher exists for `event` (global + session). */
  hasHookFor(event: HookEvent, sessionId?: string): boolean {
    if (readList(this.global, event).length > 0) {
      return true;
    }
    if (sessionId === undefined) {
      return false;
    }
    const bucket = this.sessions.get(sessionId);
    if (bucket === undefined) {
      return false;
    }
    return readList(bucket, event).length > 0;
  }

  /**
   * True when at least one matcher for `event` would actually DISPATCH on a
   * query-less call — a wildcard pattern with a non-empty `hooks` array.
   *
   * `hasHookFor` answers "is one registered", which is not the same question:
   * a matcher carrying a pattern is inert for events that supply no
   * `matchQuery`, so a caller using registration as a proxy for "something
   * will run" can act on a hook that never fires. Mirrors the two skips in
   * `executeHooks` (pattern mismatch, empty `hooks`).
   *
   * Non-allocating on purpose — `StandardGraph.canClaimPreemptSeal` reads it
   * once per streamed chunk, where `getMatchers`' defensive `slice()` would
   * allocate on every delta.
   */
  hasDispatchableHookFor(event: HookEvent, sessionId?: string): boolean {
    if (hasDispatchableInList(readList(this.global, event))) {
      return true;
    }
    if (sessionId === undefined) {
      return false;
    }
    const bucket = this.sessions.get(sessionId);
    if (bucket === undefined) {
      return false;
    }
    return hasDispatchableInList(readList(bucket, event));
  }

  private ensureSessionBucket(sessionId: string): MatcherBucket {
    const existing = this.sessions.get(sessionId);
    if (existing !== undefined) {
      return existing;
    }
    const fresh: MatcherBucket = {};
    this.sessions.set(sessionId, fresh);
    return fresh;
  }
}

function ensureList(
  bucket: MatcherBucket,
  event: HookEvent
): HookMatcher<HookEvent>[] {
  const existing = bucket[event];
  if (existing !== undefined) {
    return existing;
  }
  const fresh: HookMatcher<HookEvent>[] = [];
  bucket[event] = fresh;
  return fresh;
}

function readList(
  bucket: MatcherBucket,
  event: HookEvent
): HookMatcher<HookEvent>[] {
  return bucket[event] ?? [];
}

function hasDispatchableInList(list: HookMatcher<HookEvent>[]): boolean {
  for (const matcher of list) {
    if (
      (matcher.pattern === undefined || matcher.pattern === '') &&
      matcher.hooks.length > 0
    ) {
      return true;
    }
  }
  return false;
}

function hasResultAlteringInBucket(bucket: MatcherBucket): boolean {
  for (const event of RESULT_ALTERING_HOOK_EVENTS) {
    if (readList(bucket, event).length > 0) {
      return true;
    }
  }
  return false;
}

function removeFromList<E extends HookEvent>(
  list: HookMatcher<HookEvent>[],
  matcher: HookMatcher<E>
): boolean {
  const idx = list.indexOf(widen(matcher));
  if (idx < 0) {
    return false;
  }
  list.splice(idx, 1);
  return true;
}

/**
 * Widen a per-event matcher to the storage's uniform slot type. Unsound at
 * the type level (function parameters are contravariant) but safe by
 * construction: `HookRegistry.register<E>` only ever puts matchers into the
 * bucket slot for their own event, and reads go through `snapshot<E>`
 * which is only called with the same `E`.
 */
function widen<E extends HookEvent>(
  matcher: HookMatcher<E>
): HookMatcher<HookEvent> {
  return matcher as unknown as HookMatcher<HookEvent>;
}

/**
 * Narrow a storage list back to a per-event matcher list on the way out.
 * Sound counterpart to `widen`: the list only contains matchers that were
 * registered against `E`, because the public API enforces it on insert.
 */
function snapshot<E extends HookEvent>(
  list: readonly HookMatcher<HookEvent>[]
): HookMatcher<E>[] {
  return list.slice() as unknown as HookMatcher<E>[];
}

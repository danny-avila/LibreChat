import {
  AIMessage,
  BaseMessage,
  HumanMessage,
  SystemMessage,
  ToolMessage,
} from '@langchain/core/messages';
import type { MessageContentComplex } from '@langchain/core/messages';
import type Anthropic from '@anthropic-ai/sdk';
import type { AnthropicMessages } from '@/types/messages';
import {
  stripAnthropicCacheControl,
  stripBedrockCacheControl,
  addBedrockCacheControl,
  addBedrockTailCacheControl,
  addCacheControl,
  addTailCacheControl,
  addCacheControlToStablePrefixMessages,
  buildAnthropicCacheControl,
  buildBedrockCachePoint,
  resolvePromptCacheTtl,
  resolveBedrockPromptCacheTtl,
  supportsBedrockToolCache,
  DEFAULT_PROMPT_CACHE_TTL,
} from './cache';
import { _convertMessagesToOpenAIParams } from '@/llm/openai/utils';
import { toLangChainContent } from './langchain';
import { formatAgentMessages } from './format';
import { ContentTypes } from '@/common/enum';

type CacheControlBlock = MessageContentComplex & {
  cache_control?: { type: 'ephemeral'; ttl?: '1h' };
};

describe('addCacheControl', () => {
  test('should add cache control to the last two user messages with array content', () => {
    const messages: AnthropicMessages = [
      { role: 'user', content: [{ type: 'text', text: 'Hello' }] },
      { role: 'assistant', content: [{ type: 'text', text: 'Hi there' }] },
      { role: 'user', content: [{ type: 'text', text: 'How are you?' }] },
      {
        role: 'assistant',
        content: [{ type: 'text', text: 'I\'m doing well, thanks!' }],
      },
      { role: 'user', content: [{ type: 'text', text: 'Great!' }] },
    ];

    const result = addCacheControl(messages);

    expect(result[0].content[0]).not.toHaveProperty('cache_control');
    expect(
      (result[2].content[0] as Anthropic.TextBlockParam).cache_control
    ).toEqual({ type: 'ephemeral' });
    expect(
      (result[4].content[0] as Anthropic.TextBlockParam).cache_control
    ).toEqual({ type: 'ephemeral' });
  });

  test('should add cache control to the last two user messages with string content', () => {
    const messages: AnthropicMessages = [
      { role: 'user', content: 'Hello' },
      { role: 'assistant', content: 'Hi there' },
      { role: 'user', content: 'How are you?' },
      { role: 'assistant', content: 'I\'m doing well, thanks!' },
      { role: 'user', content: 'Great!' },
    ];

    const result = addCacheControl(messages);

    expect(result[0].content).toBe('Hello');
    expect(result[2].content[0]).toEqual({
      type: 'text',
      text: 'How are you?',
      cache_control: { type: 'ephemeral' },
    });
    expect(result[4].content[0]).toEqual({
      type: 'text',
      text: 'Great!',
      cache_control: { type: 'ephemeral' },
    });
  });

  test('should handle mixed string and array content', () => {
    const messages: AnthropicMessages = [
      { role: 'user', content: 'Hello' },
      { role: 'assistant', content: 'Hi there' },
      { role: 'user', content: [{ type: 'text', text: 'How are you?' }] },
    ];

    const result = addCacheControl(messages);

    expect(result[0].content[0]).toEqual({
      type: 'text',
      text: 'Hello',
      cache_control: { type: 'ephemeral' },
    });
    expect(
      (result[2].content[0] as Anthropic.TextBlockParam).cache_control
    ).toEqual({ type: 'ephemeral' });
  });

  test('should handle less than two user messages', () => {
    const messages: AnthropicMessages = [
      { role: 'user', content: 'Hello' },
      { role: 'assistant', content: 'Hi there' },
    ];

    const result = addCacheControl(messages);

    expect(result[0].content[0]).toEqual({
      type: 'text',
      text: 'Hello',
      cache_control: { type: 'ephemeral' },
    });
    expect(result[1].content).toBe('Hi there');
  });

  test('should return original array if no user messages', () => {
    const messages: AnthropicMessages = [
      { role: 'assistant', content: 'Hi there' },
      { role: 'assistant', content: 'How can I help?' },
    ];

    const result = addCacheControl(messages);

    expect(result).toEqual(messages);
  });

  test('should handle empty array', () => {
    const messages: AnthropicMessages = [];
    const result = addCacheControl(messages);
    expect(result).toEqual([]);
  });

  test('should handle non-array input', () => {
    const messages = 'not an array';
    /** @ts-expect-error - This is a test */
    const result = addCacheControl(messages);
    expect(result).toBe('not an array');
  });

  test('should not modify assistant messages', () => {
    const messages: AnthropicMessages = [
      { role: 'user', content: 'Hello' },
      { role: 'assistant', content: 'Hi there' },
      { role: 'user', content: 'How are you?' },
    ];

    const result = addCacheControl(messages);

    expect(result[1].content).toBe('Hi there');
  });

  test('should handle multiple content items in user messages', () => {
    const messages: AnthropicMessages = [
      {
        role: 'user',
        content: [
          { type: 'text', text: 'Hello' },
          {
            type: 'image',
            source: { type: 'url', url: 'http://example.com/image.jpg' },
          },
          { type: 'text', text: 'This is an image' },
        ],
      },
      { role: 'assistant', content: 'Hi there' },
      { role: 'user', content: 'How are you?' },
    ];

    const result = addCacheControl(messages);

    expect(result[0].content[0]).not.toHaveProperty('cache_control');
    expect(result[0].content[1]).not.toHaveProperty('cache_control');
    expect(
      (result[0].content[2] as Anthropic.TextBlockParam).cache_control
    ).toEqual({ type: 'ephemeral' });
    expect(result[2].content[0]).toEqual({
      type: 'text',
      text: 'How are you?',
      cache_control: { type: 'ephemeral' },
    });
  });

  test('should handle an array with mixed content types', () => {
    const messages: AnthropicMessages = [
      { role: 'user', content: 'Hello' },
      { role: 'assistant', content: 'Hi there' },
      { role: 'user', content: [{ type: 'text', text: 'How are you?' }] },
      { role: 'assistant', content: 'I\'m doing well, thanks!' },
      { role: 'user', content: 'Great!' },
    ];

    const result = addCacheControl(messages);

    expect(result[0].content).toEqual('Hello');
    expect(result[2].content[0]).toEqual({
      type: 'text',
      text: 'How are you?',
      cache_control: { type: 'ephemeral' },
    });
    expect(result[4].content).toEqual([
      {
        type: 'text',
        text: 'Great!',
        cache_control: { type: 'ephemeral' },
      },
    ]);
    expect(result[1].content).toBe('Hi there');
    expect(result[3].content).toBe('I\'m doing well, thanks!');
  });

  test('should handle edge case with multiple content types', () => {
    const messages: AnthropicMessages = [
      {
        role: 'user',
        content: [
          {
            type: 'image',
            source: {
              type: 'base64',
              media_type: 'image/png',
              data: 'some_base64_string',
            },
          },
          {
            type: 'image',
            source: {
              type: 'base64',
              media_type: 'image/png',
              data: 'another_base64_string',
            },
          },
          { type: 'text', text: 'what do all these images have in common' },
        ],
      },
      { role: 'assistant', content: 'I see multiple images.' },
      { role: 'user', content: 'Correct!' },
    ];

    const result = addCacheControl(messages);

    expect(result[0].content[0]).not.toHaveProperty('cache_control');
    expect(result[0].content[1]).not.toHaveProperty('cache_control');
    expect(
      (result[0].content[2] as Anthropic.ImageBlockParam).cache_control
    ).toEqual({ type: 'ephemeral' });
    expect(result[2].content[0]).toEqual({
      type: 'text',
      text: 'Correct!',
      cache_control: { type: 'ephemeral' },
    });
  });

  test('should handle user message with no text block', () => {
    const messages: AnthropicMessages = [
      {
        role: 'user',
        content: [
          {
            type: 'image',
            source: {
              type: 'base64',
              media_type: 'image/png',
              data: 'some_base64_string',
            },
          },
          {
            type: 'image',
            source: {
              type: 'base64',
              media_type: 'image/png',
              data: 'another_base64_string',
            },
          },
        ],
      },
      { role: 'assistant', content: 'I see two images.' },
      { role: 'user', content: 'Correct!' },
    ];

    const result = addCacheControl(messages);

    expect(result[0].content[0]).not.toHaveProperty('cache_control');
    expect(result[0].content[1]).not.toHaveProperty('cache_control');
    expect(result[2].content[0]).toEqual({
      type: 'text',
      text: 'Correct!',
      cache_control: { type: 'ephemeral' },
    });
  });
});

type TestMsg = {
  role?: 'user' | 'assistant' | 'system';
  content?: string | MessageContentComplex[];
};

describe('addBedrockCacheControl (Bedrock cache checkpoints)', () => {
  it('returns empty input unchanged and caches a single user message', () => {
    const empty: TestMsg[] = [];
    expect(addBedrockCacheControl(empty)).toEqual(empty);
    const single: TestMsg[] = [{ role: 'user', content: 'only' }];
    expect(addBedrockCacheControl(single)[0].content).toEqual([
      { type: ContentTypes.TEXT, text: 'only' },
      { cachePoint: { type: 'default' } },
    ]);
  });

  it('wraps latest user string content and appends separate cachePoint block', () => {
    const messages: TestMsg[] = [
      { role: 'user', content: 'Hello' },
      { role: 'assistant', content: [{ type: ContentTypes.TEXT, text: 'Hi' }] },
    ];
    const result = addBedrockCacheControl(messages);
    const user = result[0].content as MessageContentComplex[];
    const assistant = result[1].content as MessageContentComplex[];
    expect(Array.isArray(user)).toBe(true);
    expect(user[0]).toEqual({ type: ContentTypes.TEXT, text: 'Hello' });
    expect(user[1]).toEqual({ cachePoint: { type: 'default' } });
    expect(assistant).toEqual([{ type: ContentTypes.TEXT, text: 'Hi' }]);
  });

  it('inserts cachePoint after the last text when multiple text blocks exist', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [
          { type: ContentTypes.TEXT, text: 'Intro' },
          { type: ContentTypes.TEXT, text: 'Details' },
          {
            type: ContentTypes.IMAGE_FILE,
            image_file: { file_id: 'file_123' },
          },
        ],
      },
      {
        role: 'assistant',
        content: [
          { type: ContentTypes.TEXT, text: 'Reply A' },
          { type: ContentTypes.TEXT, text: 'Reply B' },
        ],
      },
    ];

    const result = addBedrockCacheControl(messages);

    const first = result[0].content as MessageContentComplex[];
    const second = result[1].content as MessageContentComplex[];

    expect(first[0]).toEqual({ type: ContentTypes.TEXT, text: 'Intro' });
    expect(first[1]).toEqual({ type: ContentTypes.TEXT, text: 'Details' });
    expect(first[2]).toEqual({ cachePoint: { type: 'default' } });

    const img = first[3] as MessageContentComplex;
    expect(img.type).toBe(ContentTypes.IMAGE_FILE);
    if (img.type === ContentTypes.IMAGE_FILE) {
      expect('image_file' in img).toBe(true);
    }

    expect(second[0]).toEqual({ type: ContentTypes.TEXT, text: 'Reply A' });
    expect(second[1]).toEqual({ type: ContentTypes.TEXT, text: 'Reply B' });
    expect(second).toHaveLength(2);
  });

  it('skips empty arrays and caches the latest non-empty user message', () => {
    const messages: TestMsg[] = [
      { role: 'user', content: [] },
      { role: 'assistant', content: [] },
      { role: 'user', content: 'latest cacheable user message' },
    ];

    const result = addBedrockCacheControl(messages);

    const first = result[0].content as MessageContentComplex[];
    const second = result[1].content as MessageContentComplex[];
    const third = result[2].content as MessageContentComplex[];

    expect(Array.isArray(first)).toBe(true);
    expect(first.length).toBe(0);

    expect(Array.isArray(second)).toBe(true);
    expect(second.length).toBe(0);
    expect(second[0]).not.toEqual({ cachePoint: { type: 'default' } });

    expect(third).toEqual([
      { type: ContentTypes.TEXT, text: 'latest cacheable user message' },
      { cachePoint: { type: 'default' } },
    ]);
  });

  it('skips empty strings and caches the latest non-empty user message', () => {
    const messages: TestMsg[] = [
      { role: 'user', content: '' },
      { role: 'assistant', content: '' },
      { role: 'user', content: 'latest cacheable user message' },
    ];

    const result = addBedrockCacheControl(messages);

    expect(result[0].content).toBe('');
    expect(result[1].content).toBe('');
    expect(result[2].content).toEqual([
      { type: ContentTypes.TEXT, text: 'latest cacheable user message' },
      { cachePoint: { type: 'default' } },
    ]);
  });

  /** (I don't think this will ever occur in actual use, but its the only branch left uncovered so I'm covering it */
  it('skips messages with non-string, non-array content', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'Older user message' }],
      },
      { role: 'assistant', content: undefined },
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'Latest user message' }],
      },
    ];

    const result = addBedrockCacheControl(messages);

    const last = result[2].content as MessageContentComplex[];
    expect(last[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'Latest user message',
    });
    expect(last[1]).toEqual({ cachePoint: { type: 'default' } });

    expect(result[1].content).toBeUndefined();

    const first = result[0].content as MessageContentComplex[];
    expect(first[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'Older user message',
    });
    expect(first[1]).toEqual({ cachePoint: { type: 'default' } });
  });

  it('preserves LangChain system message content unchanged', () => {
    const systemContent = [
      { type: ContentTypes.TEXT, text: 'Stable system text' },
      { cachePoint: { type: 'default' } },
      { type: ContentTypes.TEXT, text: 'Dynamic system text' },
    ] as MessageContentComplex[];
    const messages: BaseMessage[] = [
      new SystemMessage({ content: toLangChainContent(systemContent) }),
      new HumanMessage('Hello'),
      new AIMessage('Hi'),
    ];

    const result = addBedrockCacheControl(messages);

    expect(result[0]).toBe(messages[0]);
    expect(result[0].content).toEqual(systemContent);
  });

  it('preserves serialized system message content unchanged', () => {
    const systemContent = [
      { type: ContentTypes.TEXT, text: 'Stable system text' },
      { cachePoint: { type: 'default' } },
      { type: ContentTypes.TEXT, text: 'Dynamic system text' },
    ] as MessageContentComplex[];
    const messages: TestMsg[] = [
      { role: 'system', content: systemContent },
      { role: 'user', content: 'Hello' },
      { role: 'assistant', content: 'Hi' },
    ];

    const result = addBedrockCacheControl(messages);

    expect(result[0]).toBe(messages[0]);
    expect(result[0].content).toEqual(systemContent);
  });

  it('strips Anthropic cache_control from LangChain system messages without moving cache points', () => {
    const systemContent = [
      {
        type: ContentTypes.TEXT,
        text: 'Stable system text',
        cache_control: { type: 'ephemeral' },
      } as MessageContentComplex,
      { cachePoint: { type: 'default' } },
      {
        type: ContentTypes.TEXT,
        text: 'Dynamic system text',
        cache_control: { type: 'ephemeral' },
      } as MessageContentComplex,
    ] as MessageContentComplex[];
    const messages: BaseMessage[] = [
      new SystemMessage({ content: toLangChainContent(systemContent) }),
      new HumanMessage('Hello'),
      new AIMessage('Hi'),
    ];

    const result = addBedrockCacheControl(messages);

    expect(result[0]).not.toBe(messages[0]);
    expect(result[0].content).toEqual([
      { type: ContentTypes.TEXT, text: 'Stable system text' },
      { cachePoint: { type: 'default' } },
      { type: ContentTypes.TEXT, text: 'Dynamic system text' },
    ]);
    expect(systemContent[0]).toHaveProperty('cache_control');
    expect(systemContent[2]).toHaveProperty('cache_control');
  });

  it('strips Anthropic cache_control from serialized system messages without moving cache points', () => {
    const systemContent = [
      {
        type: ContentTypes.TEXT,
        text: 'Stable system text',
        cache_control: { type: 'ephemeral' },
      } as MessageContentComplex,
      { cachePoint: { type: 'default' } },
      {
        type: ContentTypes.TEXT,
        text: 'Dynamic system text',
        cache_control: { type: 'ephemeral' },
      } as MessageContentComplex,
    ] as MessageContentComplex[];
    const messages: TestMsg[] = [
      { role: 'system', content: systemContent },
      { role: 'user', content: 'Hello' },
      { role: 'assistant', content: 'Hi' },
    ];

    const result = addBedrockCacheControl(messages);

    expect(result[0]).not.toBe(messages[0]);
    expect(result[0].content).toEqual([
      { type: ContentTypes.TEXT, text: 'Stable system text' },
      { cachePoint: { type: 'default' } },
      { type: ContentTypes.TEXT, text: 'Dynamic system text' },
    ]);
    expect(systemContent[0]).toHaveProperty('cache_control');
    expect(systemContent[2]).toHaveProperty('cache_control');
  });

  it('skips serialized system messages while adding a cache point to the latest user turn', () => {
    const messages: TestMsg[] = [
      {
        role: 'system',
        content: [
          { type: ContentTypes.TEXT, text: 'You\'re an advanced AI assistant.' },
        ],
      },
      {
        role: 'user',
        content: [
          { type: ContentTypes.TEXT, text: 'What is the capital of France?' },
        ],
      },
    ];

    const result = addBedrockCacheControl(messages);

    let system = result[0].content as MessageContentComplex[];
    let user = result[1].content as MessageContentComplex[];

    expect(system[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'You\'re an advanced AI assistant.',
    });
    expect(system).toHaveLength(1);
    expect(user[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'What is the capital of France?',
    });
    expect(user[1]).toEqual({ cachePoint: { type: 'default' } });

    result.push({
      role: 'assistant',
      content: [
        {
          type: ContentTypes.TEXT,
          text: 'Sure! The capital of France is Paris.',
        },
      ],
    });

    const result2 = addBedrockCacheControl(result);

    system = result2[0].content as MessageContentComplex[];
    user = result2[1].content as MessageContentComplex[];
    const assistant = result2[2].content as MessageContentComplex[];

    expect(system[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'You\'re an advanced AI assistant.',
    });
    expect(system.length).toBe(1);

    expect(user[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'What is the capital of France?',
    });
    expect(user[1]).toEqual({ cachePoint: { type: 'default' } });

    expect(assistant[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'Sure! The capital of France is Paris.',
    });
    expect(assistant).toHaveLength(1);
  });

  it('is idempotent - calling multiple times does not add duplicate cache points', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'First message' }],
      },
      {
        role: 'assistant',
        content: [{ type: ContentTypes.TEXT, text: 'First response' }],
      },
    ];

    const result1 = addBedrockCacheControl(messages);
    const firstContent = result1[0].content as MessageContentComplex[];
    const secondContent = result1[1].content as MessageContentComplex[];

    expect(firstContent.length).toBe(2);
    expect(firstContent[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'First message',
    });
    expect(firstContent[1]).toEqual({ cachePoint: { type: 'default' } });

    expect(secondContent.length).toBe(1);
    expect(secondContent[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'First response',
    });

    const result2 = addBedrockCacheControl(result1);
    const firstContentAfter = result2[0].content as MessageContentComplex[];
    const secondContentAfter = result2[1].content as MessageContentComplex[];

    expect(firstContentAfter.length).toBe(2);
    expect(firstContentAfter[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'First message',
    });
    expect(firstContentAfter[1]).toEqual({ cachePoint: { type: 'default' } });

    expect(secondContentAfter.length).toBe(1);
    expect(secondContentAfter[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'First response',
    });
  });

  it('strips stale cache points and caches the latest user messages in multi-agent scenarios', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'Hello' }],
      },
      {
        role: 'assistant',
        content: [
          { type: ContentTypes.TEXT, text: 'Response from agent 1' },
          { cachePoint: { type: 'default' } },
        ],
      },
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'Follow-up question' }],
      },
    ];

    const result = addBedrockCacheControl(messages);
    const firstContent = result[0].content as MessageContentComplex[];
    const lastContent = result[2].content as MessageContentComplex[];
    const secondLastContent = result[1].content as MessageContentComplex[];

    expect(firstContent.length).toBe(2);
    expect(firstContent[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'Hello',
    });
    expect(firstContent[1]).toEqual({ cachePoint: { type: 'default' } });

    expect(lastContent.length).toBe(2);
    expect(lastContent[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'Follow-up question',
    });
    expect(lastContent[1]).toEqual({ cachePoint: { type: 'default' } });

    expect(secondLastContent.length).toBe(1);
    expect(secondLastContent[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'Response from agent 1',
    });
  });

  it('skips cachePoint on AI messages with only whitespace text and reasoning (tool-call scenario)', () => {
    const messages = [
      {
        role: 'user',
        content: [
          {
            type: ContentTypes.TEXT,
            text: 'What can you tell me about this PR?',
          },
        ],
      },
      {
        role: 'assistant',
        content: [
          { type: ContentTypes.TEXT, text: '\n\n' },
          {
            type: 'reasoning_content',
            reasoningText: { text: 'Let me look into that.', signature: 'abc' },
          },
        ] as MessageContentComplex[],
      },
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'tool result here' }],
        getType: (): 'tool' => 'tool',
      },
    ];

    const result = addBedrockCacheControl(
      messages as Parameters<typeof addBedrockCacheControl>[0]
    );
    const aiContent = result[1].content as MessageContentComplex[];
    const hasCachePoint = aiContent.some((b) => 'cachePoint' in b);
    expect(hasCachePoint).toBe(false);

    const userContent = result[0].content as MessageContentComplex[];
    expect(userContent[userContent.length - 1]).toEqual({
      cachePoint: { type: 'default' },
    });
  });

  it('keeps cachePoint on the stable user boundary through tool loops', () => {
    const messages: BaseMessage[] = [
      new HumanMessage('Use the stable prompt context.'),
      new AIMessage({
        content: 'I will call the first tool.',
        tool_calls: [{ id: 'call_1', name: 'lookup', args: { step: 1 } }],
      }),
      new ToolMessage({
        content: 'volatile tool result 1',
        tool_call_id: 'call_1',
      }),
      new AIMessage({
        content: 'I will call the second tool.',
        tool_calls: [{ id: 'call_2', name: 'lookup', args: { step: 2 } }],
      }),
      new ToolMessage({
        content: 'volatile tool result 2',
        tool_call_id: 'call_2',
      }),
    ];

    const result = addBedrockCacheControl(messages);

    const userContent = result[0].content as MessageContentComplex[];
    expect(userContent[userContent.length - 1]).toEqual({
      cachePoint: { type: 'default' },
    });

    for (const message of result.slice(1)) {
      const content = message.content;
      expect(
        Array.isArray(content) && content.some((block) => 'cachePoint' in block)
      ).toBe(false);
    }
  });
});

describe('synthetic skill/meta messages are not cache-anchored', () => {
  const hasAnthropicMarker = (m: BaseMessage): boolean =>
    Array.isArray(m.content) &&
    m.content.some((block) => 'cache_control' in block);

  const hasBedrockCachePoint = (m: BaseMessage): boolean =>
    Array.isArray(m.content) &&
    m.content.some((block) => 'cachePoint' in block);

  const skillBody = (skillName: string, content = 'SKILL BODY'): HumanMessage =>
    new HumanMessage({
      content,
      additional_kwargs: { isMeta: true, source: 'skill', skillName },
    });

  it('Anthropic: skips a trailing synthetic skill message; markers land on the real user messages', () => {
    const messages: BaseMessage[] = [
      new HumanMessage('First real question'),
      new AIMessage('Answer'),
      new HumanMessage('Second real question'),
      skillBody('pdf-analyzer'),
    ];

    const result = addCacheControl<BaseMessage>(messages);

    expect(hasAnthropicMarker(result[3])).toBe(false);
    expect(hasAnthropicMarker(result[2])).toBe(true);
    expect(hasAnthropicMarker(result[0])).toBe(true);
  });

  it('Anthropic: strips a stale marker from a synthetic skill message without re-adding one', () => {
    const stale = new HumanMessage({
      content: toLangChainContent([
        {
          type: 'text',
          text: 'SKILL BODY',
          cache_control: { type: 'ephemeral' },
        } as MessageContentComplex,
      ]),
      additional_kwargs: {
        isMeta: true,
        source: 'skill',
        skillName: 'pdf-analyzer',
      },
    });
    const messages: BaseMessage[] = [
      new HumanMessage('Real question'),
      new AIMessage('Answer'),
      stale,
    ];

    const result = addCacheControl<BaseMessage>(messages);

    expect(hasAnthropicMarker(result[2])).toBe(false);
    expect(hasAnthropicMarker(result[0])).toBe(true);
  });

  it('Anthropic: detects skill messages by additional_kwargs.source even without isMeta', () => {
    const messages: BaseMessage[] = [
      new HumanMessage('Real question'),
      new AIMessage('Answer'),
      new HumanMessage({
        content: 'SKILL BODY',
        additional_kwargs: { source: 'skill', skillName: 'pdf-analyzer' },
      }),
    ];

    const result = addCacheControl<BaseMessage>(messages);

    expect(hasAnthropicMarker(result[2])).toBe(false);
    expect(hasAnthropicMarker(result[0])).toBe(true);
  });

  it('Bedrock: skips a trailing synthetic skill message; cachePoints land on the real user messages', () => {
    const messages: BaseMessage[] = [
      new HumanMessage('First real question'),
      new AIMessage('Answer'),
      new HumanMessage('Second real question'),
      skillBody('pdf-analyzer'),
    ];

    const result = addBedrockCacheControl<BaseMessage>(messages);

    expect(hasBedrockCachePoint(result[3])).toBe(false);
    expect(hasBedrockCachePoint(result[2])).toBe(true);
    expect(hasBedrockCachePoint(result[0])).toBe(true);
  });

  it('stable-prefix fallback: anchors the real user message, not a synthetic skill message', () => {
    // Mirrors AgentContext's dynamic-tail path: the only assistant message is a
    // skill-only tool call (no text), so the assistant-only pass adds no marker
    // and the cacheable fallback runs. It must skip the reconstructed skill
    // HumanMessage and anchor the real user message instead.
    const messages: BaseMessage[] = [
      new HumanMessage('Real stable question'),
      new AIMessage({
        content: toLangChainContent([
          {
            type: 'tool_use',
            id: 'call_1',
            name: 'skill',
            input: { skillName: 'pdf-analyzer' },
          } as MessageContentComplex,
        ]),
        tool_calls: [
          { id: 'call_1', name: 'skill', args: { skillName: 'pdf-analyzer' } },
        ],
      }),
      skillBody('pdf-analyzer'),
    ];

    const result = addCacheControlToStablePrefixMessages<BaseMessage>(
      messages,
      2
    );

    expect(hasAnthropicMarker(result[2])).toBe(false);
    expect(hasAnthropicMarker(result[0])).toBe(true);
  });
});

describe('supportsBedrockToolCache', () => {
  test('returns true for Claude model ids (incl. cross-region + profile)', () => {
    expect(
      supportsBedrockToolCache('anthropic.claude-3-5-sonnet-20241022-v2:0')
    ).toBe(true);
    expect(
      supportsBedrockToolCache('us.anthropic.claude-sonnet-4-5-20250929-v1:0')
    ).toBe(true);
    expect(supportsBedrockToolCache('anthropic.claude-opus-4-6-v1')).toBe(true);
  });

  test('returns false for Nova and other non-Claude families (tool cache only)', () => {
    // Nova accepts system/message cachePoints but rejects the tool checkpoint.
    expect(supportsBedrockToolCache('us.amazon.nova-pro-v1:0')).toBe(false);
    expect(supportsBedrockToolCache('amazon.nova-lite-v1:0')).toBe(false);
    expect(supportsBedrockToolCache('meta.llama3-1-70b-instruct-v1:0')).toBe(
      false
    );
    expect(supportsBedrockToolCache('mistral.mistral-large-2407-v1:0')).toBe(
      false
    );
  });

  test('returns false for empty / missing model', () => {
    expect(supportsBedrockToolCache('')).toBe(false);
    expect(supportsBedrockToolCache(undefined)).toBe(false);
    expect(supportsBedrockToolCache(null)).toBe(false);
  });
});

describe('resolveBedrockPromptCacheTtl', () => {
  test('Claude: defaults to 1h and honors an explicit ttl', () => {
    const claude = 'us.anthropic.claude-sonnet-4-5-20250929-v1:0';
    expect(resolveBedrockPromptCacheTtl(undefined, claude)).toBe('1h');
    expect(resolveBedrockPromptCacheTtl('1h', claude)).toBe('1h');
    expect(resolveBedrockPromptCacheTtl('5m', claude)).toBe('5m');
  });

  test('Nova: clamps to 5m even when 1h is configured (extended TTL Anthropic-only)', () => {
    const nova = 'us.amazon.nova-lite-v1:0';
    expect(resolveBedrockPromptCacheTtl(undefined, nova)).toBe('5m');
    expect(resolveBedrockPromptCacheTtl('1h', nova)).toBe('5m');
    expect(resolveBedrockPromptCacheTtl('5m', nova)).toBe('5m');
  });

  test('other non-Claude families clamp to 5m', () => {
    expect(
      resolveBedrockPromptCacheTtl('1h', 'meta.llama3-1-70b-instruct-v1:0')
    ).toBe('5m');
    expect(
      resolveBedrockPromptCacheTtl('1h', 'mistral.mistral-large-2407-v1:0')
    ).toBe('5m');
  });

  test('omitted model defaults to Claude behavior (1h)', () => {
    expect(resolveBedrockPromptCacheTtl(undefined, undefined)).toBe('1h');
    expect(resolveBedrockPromptCacheTtl(undefined, null)).toBe('1h');
    expect(resolveBedrockPromptCacheTtl('1h', undefined)).toBe('1h');
  });
});

describe('stripAnthropicCacheControl', () => {
  it('removes cache_control fields from content blocks', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [
          {
            type: ContentTypes.TEXT,
            text: 'Hello',
            cache_control: { type: 'ephemeral' },
          } as MessageContentComplex,
        ],
      },
      {
        role: 'assistant',
        content: [
          {
            type: ContentTypes.TEXT,
            text: 'Hi there',
            cache_control: { type: 'ephemeral' },
          } as MessageContentComplex,
        ],
      },
    ];

    const result = stripAnthropicCacheControl(messages);

    const firstContent = result[0].content as MessageContentComplex[];
    const secondContent = result[1].content as MessageContentComplex[];

    expect(firstContent[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'Hello',
    });
    expect('cache_control' in firstContent[0]).toBe(false);

    expect(secondContent[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'Hi there',
    });
    expect('cache_control' in secondContent[0]).toBe(false);
  });

  it('handles messages without cache_control gracefully', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'Hello' }],
      },
    ];

    const result = stripAnthropicCacheControl(messages);

    expect(result[0].content).toEqual([
      { type: ContentTypes.TEXT, text: 'Hello' },
    ]);
  });

  it('handles string content gracefully', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: 'Hello',
      },
    ];

    const result = stripAnthropicCacheControl(messages);

    expect(result[0].content).toBe('Hello');
  });

  it('ignores primitive and proxy blocks without invoking proxy traps', () => {
    const unsafe = new Proxy(
      {},
      {
        ownKeys() {
          throw new Error('proxy keys must not be inspected');
        },
      }
    );
    const content = [
      'primitive',
      unsafe,
      {
        type: ContentTypes.TEXT,
        text: 'cached',
        cache_control: { type: 'ephemeral' },
      },
    ] as unknown as MessageContentComplex[];

    const result = stripAnthropicCacheControl([{ role: 'user', content }]);
    const stripped = result[0].content as unknown[];

    expect(stripped[0]).toBe('primitive');
    expect(stripped[1]).toBe(unsafe);
    expect(stripped[2]).toEqual({
      type: ContentTypes.TEXT,
      text: 'cached',
    });
  });

  it('removes a non-configurable cache_control from the clone only', () => {
    const block = { type: ContentTypes.TEXT, text: 'cached' };
    Object.defineProperty(block, 'cache_control', {
      configurable: false,
      enumerable: true,
      value: { type: 'ephemeral' },
      writable: false,
    });
    const messages = [
      {
        role: 'user',
        content: [block as MessageContentComplex],
      },
    ];

    const result = stripAnthropicCacheControl(messages);
    const stripped = (result[0].content as MessageContentComplex[])[0];

    expect('cache_control' in stripped).toBe(false);
    expect(
      (block as typeof block & { cache_control: unknown }).cache_control
    ).toEqual({ type: 'ephemeral' });
  });

  it('removes an accessor cache_control without invoking it', () => {
    let getterCalls = 0;
    const block = { type: ContentTypes.TEXT, text: 'cached' };
    Object.defineProperty(block, 'cache_control', {
      configurable: true,
      enumerable: true,
      get() {
        getterCalls++;
        throw new Error('cache getter must not run');
      },
    });

    const result = stripAnthropicCacheControl([
      {
        role: 'user',
        content: [block as MessageContentComplex],
      },
    ]);
    const stripped = (result[0].content as MessageContentComplex[])[0];

    expect(getterCalls).toBe(0);
    expect('cache_control' in stripped).toBe(false);
    expect(
      Object.getOwnPropertyDescriptor(block, 'cache_control')
    ).toBeDefined();
  });

  it('returns non-array input unchanged', () => {
    const notArray = 'not an array';
    /** @ts-expect-error - Testing invalid input */
    const result = stripAnthropicCacheControl(notArray);
    expect(result).toBe('not an array');
  });
});

describe('stripBedrockCacheControl', () => {
  it('removes cachePoint blocks from content arrays', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [
          { type: ContentTypes.TEXT, text: 'Hello' },
          { cachePoint: { type: 'default' } },
        ],
      },
      {
        role: 'assistant',
        content: [
          { type: ContentTypes.TEXT, text: 'Hi there' },
          { cachePoint: { type: 'default' } },
        ],
      },
    ];

    const result = stripBedrockCacheControl(messages);

    const firstContent = result[0].content as MessageContentComplex[];
    const secondContent = result[1].content as MessageContentComplex[];

    expect(firstContent.length).toBe(1);
    expect(firstContent[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'Hello',
    });

    expect(secondContent.length).toBe(1);
    expect(secondContent[0]).toEqual({
      type: ContentTypes.TEXT,
      text: 'Hi there',
    });
  });

  it('ignores primitive and proxy blocks while removing cache points', () => {
    let getterCalls = 0;
    const unsafe = new Proxy(
      {},
      {
        getOwnPropertyDescriptor() {
          throw new Error('proxy descriptors must not be inspected');
        },
      }
    );
    const accessorCachePoint = {};
    Object.defineProperty(accessorCachePoint, 'cachePoint', {
      configurable: true,
      enumerable: true,
      get() {
        getterCalls++;
        throw new Error('cache point getter must not run');
      },
    });
    const content = [
      42,
      unsafe,
      accessorCachePoint,
      { cachePoint: { type: 'default' } },
    ] as unknown as MessageContentComplex[];

    const result = stripBedrockCacheControl([{ role: 'user', content }]);

    expect(result[0].content).toEqual([42, unsafe]);
    expect(getterCalls).toBe(0);
  });

  it('handles messages without cachePoint blocks gracefully', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'Hello' }],
      },
    ];

    const result = stripBedrockCacheControl(messages);

    expect(result[0].content).toEqual([
      { type: ContentTypes.TEXT, text: 'Hello' },
    ]);
  });

  it('handles string content gracefully', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: 'Hello',
      },
    ];

    const result = stripBedrockCacheControl(messages);

    expect(result[0].content).toBe('Hello');
  });

  it('preserves content with type field', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [
          { type: ContentTypes.TEXT, text: 'Hello' },
          {
            type: ContentTypes.IMAGE_FILE,
            image_file: { file_id: 'file_123' },
          },
          { cachePoint: { type: 'default' } },
        ],
      },
    ];

    const result = stripBedrockCacheControl(messages);

    const content = result[0].content as MessageContentComplex[];

    expect(content.length).toBe(2);
    expect(content[0]).toEqual({ type: ContentTypes.TEXT, text: 'Hello' });
    expect(content[1]).toEqual({
      type: ContentTypes.IMAGE_FILE,
      image_file: { file_id: 'file_123' },
    });
  });

  it('returns non-array input unchanged', () => {
    const notArray = 'not an array';
    /** @ts-expect-error - Testing invalid input */
    const result = stripBedrockCacheControl(notArray);
    expect(result).toBe('not an array');
  });
});

describe('Multi-agent provider interoperability', () => {
  it('strips Bedrock cache before applying Anthropic cache (single pass)', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [
          { type: ContentTypes.TEXT, text: 'First message' },
          { cachePoint: { type: 'default' } },
        ],
      },
      {
        role: 'assistant',
        content: [
          { type: ContentTypes.TEXT, text: 'Response' },
          { cachePoint: { type: 'default' } },
        ],
      },
    ];

    /** @ts-expect-error - Testing cross-provider compatibility */
    const result = addCacheControl(messages);

    const firstContent = result[0].content as MessageContentComplex[];

    expect(firstContent.some((b) => 'cachePoint' in b)).toBe(false);
    expect('cache_control' in firstContent[0]).toBe(true);
  });

  it('strips Anthropic cache before applying Bedrock cache (single pass)', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [
          {
            type: ContentTypes.TEXT,
            text: 'First message',
            cache_control: { type: 'ephemeral' },
          } as MessageContentComplex,
        ],
      },
      {
        role: 'assistant',
        content: [
          {
            type: ContentTypes.TEXT,
            text: 'Response',
            cache_control: { type: 'ephemeral' },
          } as MessageContentComplex,
        ],
      },
    ];

    const result = addBedrockCacheControl(messages);

    const firstContent = result[0].content as MessageContentComplex[];
    const secondContent = result[1].content as MessageContentComplex[];

    expect('cache_control' in firstContent[0]).toBe(false);
    expect('cache_control' in secondContent[0]).toBe(false);

    expect(firstContent.some((b) => 'cachePoint' in b)).toBe(true);
    expect(secondContent.some((b) => 'cachePoint' in b)).toBe(false);
  });

  it('strips Bedrock cache using separate function (backwards compat)', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [
          { type: ContentTypes.TEXT, text: 'First message' },
          { cachePoint: { type: 'default' } },
        ],
      },
    ];

    const stripped = stripBedrockCacheControl(messages);
    const firstContent = stripped[0].content as MessageContentComplex[];

    expect(firstContent.some((b) => 'cachePoint' in b)).toBe(false);
    expect(firstContent.length).toBe(1);
  });

  it('strips Anthropic cache using separate function (backwards compat)', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [
          {
            type: ContentTypes.TEXT,
            text: 'First message',
            cache_control: { type: 'ephemeral' },
          } as MessageContentComplex,
        ],
      },
    ];

    const stripped = stripAnthropicCacheControl(messages);
    const firstContent = stripped[0].content as MessageContentComplex[];

    expect('cache_control' in firstContent[0]).toBe(false);
  });
});

describe('Immutability - addCacheControl does not mutate original messages', () => {
  it('should not mutate original messages when adding cache control to string content', () => {
    const originalMessages: TestMsg[] = [
      { role: 'user', content: 'Hello' },
      { role: 'assistant', content: 'Hi there' },
      { role: 'user', content: 'How are you?' },
    ];

    const originalFirstContent = originalMessages[0].content;
    const originalThirdContent = originalMessages[2].content;

    const result = addCacheControl(originalMessages as never);

    expect(originalMessages[0].content).toBe(originalFirstContent);
    expect(originalMessages[2].content).toBe(originalThirdContent);
    expect(typeof originalMessages[0].content).toBe('string');
    expect(typeof originalMessages[2].content).toBe('string');

    expect(Array.isArray(result[0].content)).toBe(true);
    expect(Array.isArray(result[2].content)).toBe(true);
  });

  it('should not mutate original messages when adding cache control to array content', () => {
    const originalMessages: TestMsg[] = [
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'Hello' }],
      },
      { role: 'assistant', content: 'Hi there' },
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'How are you?' }],
      },
    ];

    const originalFirstBlock = {
      ...(originalMessages[0].content as MessageContentComplex[])[0],
    };
    const originalThirdBlock = {
      ...(originalMessages[2].content as MessageContentComplex[])[0],
    };

    const result = addCacheControl(originalMessages as never);

    const firstContent = originalMessages[0].content as MessageContentComplex[];
    const thirdContent = originalMessages[2].content as MessageContentComplex[];

    expect('cache_control' in firstContent[0]).toBe(false);
    expect('cache_control' in thirdContent[0]).toBe(false);
    expect(firstContent[0]).toEqual(originalFirstBlock);
    expect(thirdContent[0]).toEqual(originalThirdBlock);

    const resultFirstContent = result[0].content as MessageContentComplex[];
    const resultThirdContent = result[2].content as MessageContentComplex[];
    expect('cache_control' in resultFirstContent[0]).toBe(true);
    expect('cache_control' in resultThirdContent[0]).toBe(true);
  });

  it('should not mutate original messages when stripping existing cache control', () => {
    const originalMessages: TestMsg[] = [
      {
        role: 'user',
        content: [
          {
            type: ContentTypes.TEXT,
            text: 'Hello',
            cache_control: { type: 'ephemeral' },
          } as MessageContentComplex,
        ],
      },
      { role: 'assistant', content: 'Hi there' },
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'How are you?' }],
      },
    ];

    const originalFirstBlock = (
      originalMessages[0].content as MessageContentComplex[]
    )[0];

    addCacheControl(originalMessages as never);

    expect('cache_control' in originalFirstBlock).toBe(true);
  });

  it('should remove lc_kwargs to prevent serialization mismatch for LangChain messages', () => {
    type LangChainLikeMsg = TestMsg & {
      lc_kwargs?: { content?: MessageContentComplex[] };
    };

    const messagesWithLcKwargs: LangChainLikeMsg[] = [
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'First user message' }],
        lc_kwargs: {
          content: [{ type: ContentTypes.TEXT, text: 'First user message' }],
        },
      },
      {
        role: 'assistant',
        content: [{ type: ContentTypes.TEXT, text: 'Assistant response' }],
        lc_kwargs: {
          content: [{ type: ContentTypes.TEXT, text: 'Assistant response' }],
        },
      },
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'Second user message' }],
        lc_kwargs: {
          content: [{ type: ContentTypes.TEXT, text: 'Second user message' }],
        },
      },
    ];

    const result = addCacheControl(messagesWithLcKwargs as never);

    const resultFirst = result[0] as LangChainLikeMsg;
    const resultThird = result[2] as LangChainLikeMsg;

    expect(resultFirst.lc_kwargs).toBeUndefined();
    expect(resultThird.lc_kwargs).toBeUndefined();

    const firstContent = resultFirst.content as MessageContentComplex[];
    expect('cache_control' in firstContent[0]).toBe(true);

    const originalFirst = messagesWithLcKwargs[0];
    const originalContent = originalFirst.content as MessageContentComplex[];
    const originalLcContent = originalFirst.lc_kwargs
      ?.content as MessageContentComplex[];
    expect('cache_control' in originalContent[0]).toBe(false);
    expect('cache_control' in originalLcContent[0]).toBe(false);
  });
});

describe('Immutability - addBedrockCacheControl does not mutate original messages', () => {
  it('should not mutate original messages when adding cache points to string content', () => {
    const originalMessages: TestMsg[] = [
      { role: 'user', content: 'Hello' },
      { role: 'assistant', content: 'Hi there' },
    ];

    const originalFirstContent = originalMessages[0].content;
    const originalSecondContent = originalMessages[1].content;

    const result = addBedrockCacheControl(originalMessages);

    expect(originalMessages[0].content).toBe(originalFirstContent);
    expect(originalMessages[1].content).toBe(originalSecondContent);
    expect(typeof originalMessages[0].content).toBe('string');
    expect(typeof originalMessages[1].content).toBe('string');

    expect(Array.isArray(result[0].content)).toBe(true);
    expect(result[1].content).toBe('Hi there');
  });

  it('should not mutate original messages when adding cache points to array content', () => {
    const originalMessages: TestMsg[] = [
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'Hello' }],
      },
      {
        role: 'assistant',
        content: [{ type: ContentTypes.TEXT, text: 'Hi there' }],
      },
    ];

    const originalFirstContentLength = (
      originalMessages[0].content as MessageContentComplex[]
    ).length;
    const originalSecondContentLength = (
      originalMessages[1].content as MessageContentComplex[]
    ).length;

    const result = addBedrockCacheControl(originalMessages);

    const firstContent = originalMessages[0].content as MessageContentComplex[];
    const secondContent = originalMessages[1]
      .content as MessageContentComplex[];

    expect(firstContent.length).toBe(originalFirstContentLength);
    expect(secondContent.length).toBe(originalSecondContentLength);
    expect(firstContent.some((b) => 'cachePoint' in b)).toBe(false);
    expect(secondContent.some((b) => 'cachePoint' in b)).toBe(false);

    const resultFirstContent = result[0].content as MessageContentComplex[];
    const resultSecondContent = result[1].content as MessageContentComplex[];
    expect(resultFirstContent.length).toBe(originalFirstContentLength + 1);
    expect(resultSecondContent.length).toBe(originalSecondContentLength);
    expect(resultFirstContent.some((b) => 'cachePoint' in b)).toBe(true);
    expect(resultSecondContent.some((b) => 'cachePoint' in b)).toBe(false);
  });

  it('should not mutate original messages when stripping existing cache control', () => {
    const originalMessages: TestMsg[] = [
      {
        role: 'user',
        content: [
          {
            type: ContentTypes.TEXT,
            text: 'Hello',
            cache_control: { type: 'ephemeral' },
          } as MessageContentComplex,
        ],
      },
      {
        role: 'assistant',
        content: [
          { type: ContentTypes.TEXT, text: 'Hi there' },
          { cachePoint: { type: 'default' } },
        ],
      },
    ];

    const originalFirstBlock = (
      originalMessages[0].content as MessageContentComplex[]
    )[0];
    const originalSecondContentLength = (
      originalMessages[1].content as MessageContentComplex[]
    ).length;

    addBedrockCacheControl(originalMessages);

    expect('cache_control' in originalFirstBlock).toBe(true);
    expect(
      (originalMessages[1].content as MessageContentComplex[]).length
    ).toBe(originalSecondContentLength);
  });

  it('should allow different providers to process same messages without cross-contamination', () => {
    const sharedMessages: TestMsg[] = [
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'Shared message 1' }],
      },
      {
        role: 'assistant',
        content: [{ type: ContentTypes.TEXT, text: 'Shared response 1' }],
      },
    ];

    const bedrockResult = addBedrockCacheControl(sharedMessages);

    const anthropicResult = addCacheControl(sharedMessages as never);

    const originalFirstContent = sharedMessages[0]
      .content as MessageContentComplex[];
    expect(originalFirstContent.some((b) => 'cachePoint' in b)).toBe(false);
    expect('cache_control' in originalFirstContent[0]).toBe(false);

    const bedrockFirstContent = bedrockResult[0]
      .content as MessageContentComplex[];
    expect(bedrockFirstContent.some((b) => 'cachePoint' in b)).toBe(true);
    expect('cache_control' in bedrockFirstContent[0]).toBe(false);

    const anthropicFirstContent = anthropicResult[0]
      .content as MessageContentComplex[];
    expect(anthropicFirstContent.some((b) => 'cachePoint' in b)).toBe(false);
    expect('cache_control' in anthropicFirstContent[0]).toBe(true);
  });

  it('should remove lc_kwargs to prevent serialization mismatch for LangChain messages', () => {
    type LangChainLikeMsg = TestMsg & {
      lc_kwargs?: { content?: MessageContentComplex[] };
    };

    const messagesWithLcKwargs: LangChainLikeMsg[] = [
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'User message' }],
        lc_kwargs: {
          content: [{ type: ContentTypes.TEXT, text: 'User message' }],
        },
      },
      {
        role: 'assistant',
        content: [{ type: ContentTypes.TEXT, text: 'Assistant response' }],
        lc_kwargs: {
          content: [{ type: ContentTypes.TEXT, text: 'Assistant response' }],
        },
      },
    ];

    const bedrockResult = addBedrockCacheControl(messagesWithLcKwargs);

    const resultFirst = bedrockResult[0] as LangChainLikeMsg;
    const resultSecond = bedrockResult[1] as LangChainLikeMsg;

    expect(resultFirst.lc_kwargs).toBeUndefined();
    expect(resultSecond.lc_kwargs).toBeUndefined();

    const firstContent = resultFirst.content as MessageContentComplex[];
    expect(firstContent.some((b) => 'cachePoint' in b)).toBe(true);

    const originalFirst = messagesWithLcKwargs[0];
    const originalContent = originalFirst.content as MessageContentComplex[];
    const originalLcContent = originalFirst.lc_kwargs
      ?.content as MessageContentComplex[];
    expect(originalContent.some((b) => 'cachePoint' in b)).toBe(false);
    expect(originalLcContent.some((b) => 'cachePoint' in b)).toBe(false);
  });
});

describe('Multi-turn cache cleanup', () => {
  it('strips stale Bedrock cache points from previous turns before applying new ones', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [
          { type: ContentTypes.TEXT, text: 'Turn 1 message 1' },
          { cachePoint: { type: 'default' } },
        ],
      },
      {
        role: 'assistant',
        content: [
          { type: ContentTypes.TEXT, text: 'Turn 1 response 1' },
          { cachePoint: { type: 'default' } },
        ],
      },
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'Turn 2 message 2' }],
      },
      {
        role: 'assistant',
        content: [{ type: ContentTypes.TEXT, text: 'Turn 2 response 2' }],
      },
    ];

    const result = addBedrockCacheControl(messages);

    const cachePointCount = result.reduce((count, msg) => {
      if (Array.isArray(msg.content)) {
        return (
          count +
          msg.content.filter(
            (block) => 'cachePoint' in block && !('type' in block)
          ).length
        );
      }
      return count;
    }, 0);

    expect(cachePointCount).toBe(2);

    const lastContent = result[3].content as MessageContentComplex[];
    const secondLastContent = result[2].content as MessageContentComplex[];

    expect(lastContent.some((b) => 'cachePoint' in b)).toBe(false);
    expect(secondLastContent.some((b) => 'cachePoint' in b)).toBe(true);

    const firstContent = result[0].content as MessageContentComplex[];
    const secondContent = result[1].content as MessageContentComplex[];

    expect(firstContent.some((b) => 'cachePoint' in b)).toBe(true);
    expect(secondContent.some((b) => 'cachePoint' in b)).toBe(false);
  });

  it('strips stale Anthropic cache_control from previous turns before applying new ones', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [
          {
            type: ContentTypes.TEXT,
            text: 'Turn 1 message 1',
            cache_control: { type: 'ephemeral' },
          } as MessageContentComplex,
        ],
      },
      {
        role: 'assistant',
        content: [{ type: ContentTypes.TEXT, text: 'Turn 1 response 1' }],
      },
      {
        role: 'user',
        content: [
          {
            type: ContentTypes.TEXT,
            text: 'Turn 2 message 2',
            cache_control: { type: 'ephemeral' },
          } as MessageContentComplex,
        ],
      },
      {
        role: 'assistant',
        content: [{ type: ContentTypes.TEXT, text: 'Turn 2 response 2' }],
      },
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'Turn 3 message 3' }],
      },
    ];

    /** @ts-expect-error - Testing cross-provider compatibility */
    const result = addCacheControl(messages);

    const cacheControlCount = result.reduce((count, msg) => {
      if (Array.isArray(msg.content)) {
        return (
          count +
          msg.content.filter(
            (block) => 'cache_control' in block && 'type' in block
          ).length
        );
      }
      return count;
    }, 0);

    expect(cacheControlCount).toBe(2);

    const lastContent = result[4].content as MessageContentComplex[];
    const thirdContent = result[2].content as MessageContentComplex[];

    expect('cache_control' in lastContent[0]).toBe(true);
    expect('cache_control' in thirdContent[0]).toBe(true);

    const firstContent = result[0].content as MessageContentComplex[];

    expect('cache_control' in firstContent[0]).toBe(false);
  });
});

describe('LangChain message type preservation', () => {
  it('preserves direct roles for formatted LangChain messages after addCacheControl', () => {
    const { messages } = formatAgentMessages([
      { role: 'user', content: 'Hello' },
      { role: 'assistant', content: 'Hi there' },
      { role: 'user', content: 'Thanks' },
    ]);

    const result = addCacheControl(messages);

    expect(result.map((message) => message.role)).toEqual([
      'user',
      'assistant',
      'user',
    ]);
    expect(result[0]).toBeInstanceOf(HumanMessage);
    expect(result[0]).not.toBe(messages[0]);
    expect(Object.keys(result[0])).not.toContain('role');
    expect(result[1]).toBe(messages[1]);
    expect(result[2]).not.toBe(messages[2]);
  });

  it('should preserve instanceof for LangChain messages after addCacheControl', () => {
    const messages: BaseMessage[] = [
      new HumanMessage({ content: [{ type: 'text', text: 'Hello' }] }),
      new AIMessage({
        content: [{ type: 'text', text: 'Using a tool' }],
        tool_calls: [
          { id: 'call_1', name: 'test', args: {}, type: 'tool_call' as const },
        ],
      }),
      new ToolMessage({ content: 'result', tool_call_id: 'call_1' }),
      new HumanMessage({ content: [{ type: 'text', text: 'Thanks' }] }),
      new AIMessage({ content: [{ type: 'text', text: 'No problem' }] }),
    ];

    const result = addCacheControl(messages);

    expect(result[0]).toBeInstanceOf(HumanMessage);
    expect(result[1]).toBeInstanceOf(AIMessage);
    expect(result[2]).toBeInstanceOf(ToolMessage);
    expect(result[3]).toBeInstanceOf(HumanMessage);
    expect(result[4]).toBeInstanceOf(AIMessage);

    // Verify tool_calls are preserved on the AIMessage
    expect((result[1] as AIMessage).tool_calls).toHaveLength(1);
    expect((result[1] as AIMessage).tool_calls![0].name).toBe('test');

    // Verify tool_call_id is preserved on the ToolMessage
    expect((result[2] as ToolMessage).tool_call_id).toBe('call_1');
  });

  it('should preserve instanceof for LangChain messages after addBedrockCacheControl', () => {
    const messages: BaseMessage[] = [
      new HumanMessage({ content: [{ type: 'text', text: 'Hello' }] }),
      new AIMessage({
        content: [
          { type: 'text', text: '\n\n' },
          { type: 'reasoning_content', reasoningText: { text: 'thinking...' } },
          { type: 'text', text: 'Using a tool' },
        ],
        tool_calls: [
          {
            id: 'call_1',
            name: 'navigate',
            args: { url: 'test' },
            type: 'tool_call' as const,
          },
        ],
      }),
      new ToolMessage({ content: 'navigated', tool_call_id: 'call_1' }),
      new HumanMessage({ content: [{ type: 'text', text: 'Now what?' }] }),
    ];

    const result = addBedrockCacheControl(messages);

    expect(result[0]).toBeInstanceOf(HumanMessage);
    expect(result[1]).toBeInstanceOf(AIMessage);
    expect(result[2]).toBeInstanceOf(ToolMessage);
    expect(result[3]).toBeInstanceOf(HumanMessage);

    // Verify reasoning content is preserved
    const aiContent = (result[1] as AIMessage)
      .content as MessageContentComplex[];
    expect(
      aiContent.some(
        (c) => (c as { type: string }).type === 'reasoning_content'
      )
    ).toBe(true);

    // Verify tool_calls are preserved
    expect((result[1] as AIMessage).tool_calls).toHaveLength(1);
    expect((result[1] as AIMessage).tool_calls![0].name).toBe('navigate');
  });
});

describe('OpenRouter prompt caching (reuses addCacheControl)', () => {
  it('adds cache_control to LangChain messages for OpenRouter (same format as Anthropic)', () => {
    const messages: BaseMessage[] = [
      new HumanMessage({ content: [{ type: 'text', text: 'System context' }] }),
      new AIMessage({ content: [{ type: 'text', text: 'Acknowledged' }] }),
      new HumanMessage({ content: [{ type: 'text', text: 'User query' }] }),
    ];

    const result = addCacheControl(messages);

    const firstContent = result[0].content as MessageContentComplex[];
    const lastContent = result[2].content as MessageContentComplex[];

    expect((firstContent[0] as CacheControlBlock).cache_control).toEqual({
      type: 'ephemeral',
    });
    expect((lastContent[0] as CacheControlBlock).cache_control).toEqual({
      type: 'ephemeral',
    });
  });

  it('preserves cache_control through OpenAI message conversion used by OpenRouter', () => {
    const messages: BaseMessage[] = [
      new HumanMessage({
        content: [
          {
            type: 'text',
            text: 'Hello',
            cache_control: { type: 'ephemeral' },
          },
        ],
      }),
      new AIMessage({ content: 'Hi there' }),
      new HumanMessage({
        content: [
          {
            type: 'text',
            text: 'Follow-up',
            cache_control: { type: 'ephemeral' },
          },
        ],
      }),
    ];

    const converted = _convertMessagesToOpenAIParams(messages);

    const firstUserContent = converted[0].content as CacheControlBlock[];
    const lastUserContent = converted[2].content as CacheControlBlock[];

    expect(firstUserContent[0]).toHaveProperty('cache_control');
    expect(firstUserContent[0].cache_control).toEqual({ type: 'ephemeral' });
    expect(lastUserContent[0]).toHaveProperty('cache_control');
    expect(lastUserContent[0].cache_control).toEqual({ type: 'ephemeral' });
  });

  it('end-to-end: addCacheControl then convert preserves breakpoints for OpenRouter', () => {
    const messages: BaseMessage[] = [
      new HumanMessage({ content: 'First message with context' }),
      new AIMessage({ content: 'Response' }),
      new HumanMessage({ content: 'Second question' }),
    ];

    const cached = addCacheControl(messages);
    const converted = _convertMessagesToOpenAIParams(
      cached,
      'anthropic/claude-sonnet-4-20250514'
    );

    const firstUser = converted[0];
    const lastUser = converted[2];

    expect(Array.isArray(firstUser.content)).toBe(true);
    expect((firstUser.content as CacheControlBlock[])[0]).toHaveProperty(
      'cache_control'
    );

    expect(Array.isArray(lastUser.content)).toBe(true);
    expect((lastUser.content as CacheControlBlock[])[0]).toHaveProperty(
      'cache_control'
    );
  });

  it('strips Bedrock cache before applying OpenRouter/Anthropic cache', () => {
    const messages: TestMsg[] = [
      {
        role: 'user',
        content: [
          { type: ContentTypes.TEXT, text: 'First message' },
          { cachePoint: { type: 'default' } },
        ],
      },
      {
        role: 'assistant',
        content: [
          { type: ContentTypes.TEXT, text: 'Response' },
          { cachePoint: { type: 'default' } },
        ],
      },
      {
        role: 'user',
        content: [{ type: ContentTypes.TEXT, text: 'Follow-up' }],
      },
    ];

    /** @ts-expect-error - Testing cross-provider compatibility */
    const result = addCacheControl(messages);

    for (const msg of result) {
      if (Array.isArray(msg.content)) {
        expect(
          (msg.content as MessageContentComplex[]).some(
            (b) => 'cachePoint' in b
          )
        ).toBe(false);
      }
    }

    const lastContent = result[2].content as MessageContentComplex[];
    expect('cache_control' in lastContent[0]).toBe(true);
  });
});

describe('prompt-cache TTL (1h default, 5m legacy)', () => {
  describe('resolvePromptCacheTtl', () => {
    it('defaults to the 1h extended cache when unset', () => {
      expect(resolvePromptCacheTtl(undefined)).toBe('1h');
      expect(DEFAULT_PROMPT_CACHE_TTL).toBe('1h');
    });

    it('passes an explicit value through unchanged', () => {
      expect(resolvePromptCacheTtl('5m')).toBe('5m');
      expect(resolvePromptCacheTtl('1h')).toBe('1h');
    });
  });

  describe('marker builders', () => {
    it('buildAnthropicCacheControl adds ttl only for 1h', () => {
      expect(buildAnthropicCacheControl('1h')).toEqual({
        type: 'ephemeral',
        ttl: '1h',
      });
      // 5m / undefined stay byte-identical to the legacy marker (no ttl)
      expect(buildAnthropicCacheControl('5m')).toEqual({ type: 'ephemeral' });
      expect(buildAnthropicCacheControl()).toEqual({ type: 'ephemeral' });
    });

    it('buildBedrockCachePoint adds ttl only for 1h', () => {
      expect(buildBedrockCachePoint('1h')).toEqual({
        type: 'default',
        ttl: '1h',
      });
      expect(buildBedrockCachePoint('5m')).toEqual({ type: 'default' });
      expect(buildBedrockCachePoint()).toEqual({ type: 'default' });
    });
  });

  describe('addTailCacheControl threads ttl', () => {
    const baseMessages = (): AnthropicMessages => [
      { role: 'user', content: 'Hello' },
      { role: 'assistant', content: 'Hi there' },
    ];

    it('stamps a 1h cache_control on the tail block', () => {
      const result = addTailCacheControl(baseMessages(), '1h');
      const tail = result[result.length - 1].content as MessageContentComplex[];
      expect(tail[tail.length - 1]).toEqual({
        type: 'text',
        text: 'Hi there',
        cache_control: { type: 'ephemeral', ttl: '1h' },
      });
    });

    it('omits ttl for 5m and for the unspecified (legacy) default', () => {
      for (const ttl of ['5m', undefined] as const) {
        const result = addTailCacheControl(baseMessages(), ttl);
        const tail = result[result.length - 1]
          .content as MessageContentComplex[];
        expect(
          (tail[tail.length - 1] as Anthropic.TextBlockParam).cache_control
        ).toEqual({ type: 'ephemeral' });
      }
    });
  });

  describe('addCacheControl threads ttl', () => {
    it('stamps a 1h cache_control on the latest user messages', () => {
      const messages: AnthropicMessages = [
        { role: 'user', content: 'first' },
        { role: 'assistant', content: 'reply' },
        { role: 'user', content: 'second' },
      ];
      const result = addCacheControl(messages, '1h');
      const lastUser = result[2].content as MessageContentComplex[];
      expect((lastUser[0] as Anthropic.TextBlockParam).cache_control).toEqual({
        type: 'ephemeral',
        ttl: '1h',
      });
    });
  });

  describe('addCacheControlToStablePrefixMessages threads ttl', () => {
    it('stamps 1h on every stable-prefix marker', () => {
      const messages: AnthropicMessages = [
        { role: 'user', content: 'turn 1' },
        { role: 'assistant', content: 'reply 1' },
        { role: 'user', content: 'turn 2' },
        { role: 'assistant', content: 'reply 2' },
      ];
      const result = addCacheControlToStablePrefixMessages(messages, 2, '1h');
      const marked = result
        .flatMap((m) =>
          Array.isArray(m.content) ? (m.content as MessageContentComplex[]) : []
        )
        .filter((block) => 'cache_control' in block);
      expect(marked.length).toBeGreaterThan(0);
      for (const block of marked) {
        expect((block as Anthropic.TextBlockParam).cache_control).toEqual({
          type: 'ephemeral',
          ttl: '1h',
        });
      }
    });
  });

  describe('addBedrockTailCacheControl threads ttl', () => {
    const messages = (): TestMsg[] => [
      { role: 'user', content: 'Hello' },
      { role: 'assistant', content: 'Hi' },
    ];

    it('stamps a 1h cachePoint on the tail message', () => {
      const result = addBedrockTailCacheControl(messages(), '1h');
      const last = result[result.length - 1].content as MessageContentComplex[];
      expect(last[last.length - 1]).toEqual({
        cachePoint: { type: 'default', ttl: '1h' },
      });
    });

    it('omits ttl for 5m and the legacy default', () => {
      for (const ttl of ['5m', undefined] as const) {
        const result = addBedrockTailCacheControl(messages(), ttl);
        const last = result[result.length - 1]
          .content as MessageContentComplex[];
        expect(last[last.length - 1]).toEqual({
          cachePoint: { type: 'default' },
        });
      }
    });

    it('normalizes a stale 5m system cachePoint to the resolved tail ttl', () => {
      const msgs: TestMsg[] = [
        {
          role: 'system',
          content: [
            { type: ContentTypes.TEXT, text: 'System' },
            { cachePoint: { type: 'default' } } as MessageContentComplex,
          ],
        },
        { role: 'user', content: 'Hello' },
        { role: 'assistant', content: 'Hi' },
      ];
      const result = addBedrockTailCacheControl(msgs, '1h');
      // Stale 5m system checkpoint is upgraded to 1h so it never precedes the
      // 1h message tail (Bedrock requires longer-TTL checkpoints first).
      const system = result[0].content as MessageContentComplex[];
      expect(system[system.length - 1]).toEqual({
        cachePoint: { type: 'default', ttl: '1h' },
      });
      const tail = result[result.length - 1].content as MessageContentComplex[];
      expect(tail[tail.length - 1]).toEqual({
        cachePoint: { type: 'default', ttl: '1h' },
      });
    });
  });

  describe('addBedrockCacheControl threads ttl', () => {
    it('stamps a 1h cachePoint when configured', () => {
      const messages: TestMsg[] = [
        { role: 'user', content: 'Hello' },
        { role: 'assistant', content: 'Hi' },
      ];
      const result = addBedrockCacheControl(messages, '1h');
      // Only one user message present, so the cachePoint anchors on it.
      const user = result[0].content as MessageContentComplex[];
      expect(user[user.length - 1]).toEqual({
        cachePoint: { type: 'default', ttl: '1h' },
      });
    });
  });
});

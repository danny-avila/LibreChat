/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  AIMessage,
  AIMessageChunk,
  ToolMessage,
  BaseMessage,
  HumanMessage,
  SystemMessage,
} from '@langchain/core/messages';
import type {
  MessageContent,
  MessageContentImageUrl,
} from '@langchain/core/messages';
import type { RunnableConfig } from '@langchain/core/runnables';
import type { ToolCall } from '@langchain/core/messages/tool';
import type {
  BedrockReasoningContentText,
  ExtendedMessageContent,
  GoogleReasoningContentText,
  MessageContentComplex,
  ReasoningContentText,
  SummaryContentBlock,
  SummaryCoverage,
  ThinkingContentText,
  ToolCallContent,
  ToolResultContent,
  ToolCallPart,
  TPayload,
  TMessage,
} from '@/types';
import {
  compactToolContent,
  getToolContentCharLength,
  isAtomicToolContentBlock,
  serializeStructuredValueBounded,
} from '@/utils/toolContent';
import { normalizeAnthropicToolCallId } from '@/llm/anthropic/utils/message_inputs';
import { toLangChainContent, toLangChainMessageFields } from './langchain';
import { HARD_MAX_TOOL_RESULT_CHARS } from '@/utils/truncation';
import { Providers, ContentTypes, Constants } from '@/common';
import { emitAgentLog } from '@/utils/events';

interface MediaMessageParams {
  message: {
    role: string;
    content: string;
    name?: string;
    [key: string]: any;
  };
  mediaParts: MessageContentComplex[];
  endpoint?: Providers;
}

/**
 * Formats a message with media content (images, documents, videos, audios) to API payload format.
 *
 * @param params - The parameters for formatting.
 * @returns - The formatted message.
 */
export const formatMediaMessage = ({
  message,
  endpoint,
  mediaParts,
}: MediaMessageParams): {
  role: string;
  content: MessageContentComplex[];
  name?: string;
  [key: string]: any;
} => {
  // Create a new object to avoid mutating the input
  const result: {
    role: string;
    content: MessageContentComplex[];
    name?: string;
    [key: string]: any;
  } = {
    ...message,
    content: [] as MessageContentComplex[],
  };

  if (endpoint === Providers.ANTHROPIC) {
    result.content = [
      ...mediaParts,
      { type: ContentTypes.TEXT, text: message.content },
    ] as MessageContentComplex[];
    return result;
  }

  result.content = [
    { type: ContentTypes.TEXT, text: message.content },
    ...mediaParts,
  ] as MessageContentComplex[];

  return result;
};

interface MessageInput {
  role?: string;
  _name?: string;
  sender?: string;
  text?: string;
  content?: string | MessageContentComplex[];
  image_urls?: MessageContentImageUrl[];
  documents?: MessageContentComplex[];
  videos?: MessageContentComplex[];
  audios?: MessageContentComplex[];
  lc_id?: string[];
  [key: string]: any;
}

interface FormatMessageParams {
  message: MessageInput;
  userName?: string;
  assistantName?: string;
  endpoint?: Providers;
  langChain?: boolean;
}

export type LangChainMessageRole = 'system' | 'user' | 'assistant' | 'tool';

export type RoleBearingMessage<T extends BaseMessage = BaseMessage> = T & {
  role: LangChainMessageRole;
};

export function withMessageRole<T extends BaseMessage>(
  message: T,
  role: LangChainMessageRole
): RoleBearingMessage<T> {
  const roleMessage = message as T & { role?: LangChainMessageRole };
  if (roleMessage.role === role) {
    return roleMessage as RoleBearingMessage<T>;
  }
  Object.defineProperty(roleMessage, 'role', {
    value: role,
    writable: true,
    enumerable: false,
    configurable: true,
  });
  return roleMessage as RoleBearingMessage<T>;
}

interface FormattedMessage {
  role: string;
  content: string | MessageContentComplex[];
  name?: string;
  [key: string]: any;
}

/**
 * Formats a message to OpenAI payload format based on the provided options.
 *
 * @param params - The parameters for formatting.
 * @returns - The formatted message.
 */
export const formatMessage = ({
  message,
  userName,
  endpoint,
  assistantName,
  langChain = false,
}: FormatMessageParams):
  | FormattedMessage
  | RoleBearingMessage<HumanMessage>
  | RoleBearingMessage<AIMessage>
  | RoleBearingMessage<SystemMessage> => {
  // eslint-disable-next-line prefer-const
  let { role: _role, _name, sender, text, content: _content, lc_id } = message;
  if (lc_id && lc_id[2] && !langChain) {
    const roleMapping: Record<string, string> = {
      SystemMessage: 'system',
      HumanMessage: 'user',
      AIMessage: 'assistant',
    };
    _role = roleMapping[lc_id[2]] || _role;
  }
  const role =
    _role ??
    (sender != null && sender && sender.toLowerCase() === 'user'
      ? 'user'
      : 'assistant');
  const content = _content ?? text ?? '';
  const formattedMessage: FormattedMessage = {
    role,
    content,
  };

  // Set name fields first
  if (_name != null && _name) {
    formattedMessage.name = _name;
  }

  if (userName != null && userName && formattedMessage.role === 'user') {
    formattedMessage.name = userName;
  }

  if (
    assistantName != null &&
    assistantName &&
    formattedMessage.role === 'assistant'
  ) {
    formattedMessage.name = assistantName;
  }

  if (formattedMessage.name != null && formattedMessage.name) {
    // Conform to API regex: ^[a-zA-Z0-9_-]{1,64}$
    // https://community.openai.com/t/the-format-of-the-name-field-in-the-documentation-is-incorrect/175684/2
    formattedMessage.name = formattedMessage.name.replace(
      /[^a-zA-Z0-9_-]/g,
      '_'
    );

    if (formattedMessage.name.length > 64) {
      formattedMessage.name = formattedMessage.name.substring(0, 64);
    }
  }

  const { image_urls, documents, videos, audios } = message;
  const mediaParts: MessageContentComplex[] = [];

  if (Array.isArray(documents) && documents.length > 0) {
    mediaParts.push(...documents);
  }

  if (Array.isArray(videos) && videos.length > 0) {
    mediaParts.push(...videos);
  }

  if (Array.isArray(audios) && audios.length > 0) {
    mediaParts.push(...audios);
  }

  if (Array.isArray(image_urls) && image_urls.length > 0) {
    mediaParts.push(...image_urls);
  }

  if (mediaParts.length > 0 && role === 'user') {
    const mediaMessage = formatMediaMessage({
      message: {
        ...formattedMessage,
        content:
          typeof formattedMessage.content === 'string'
            ? formattedMessage.content
            : '',
      },
      mediaParts,
      endpoint,
    });

    if (!langChain) {
      return mediaMessage;
    }

    return withMessageRole(
      new HumanMessage(toLangChainMessageFields(mediaMessage)),
      'user'
    );
  }

  if (!langChain) {
    return formattedMessage;
  }

  if (role === 'user') {
    return withMessageRole(
      new HumanMessage(toLangChainMessageFields(formattedMessage)),
      'user'
    );
  } else if (role === 'assistant') {
    return withMessageRole(
      new AIMessage(toLangChainMessageFields(formattedMessage)),
      'assistant'
    );
  } else {
    return withMessageRole(
      new SystemMessage(toLangChainMessageFields(formattedMessage)),
      'system'
    );
  }
};

/**
 * Formats an array of messages for LangChain.
 *
 * @param messages - The array of messages to format.
 * @param formatOptions - The options for formatting each message.
 * @returns - The array of formatted LangChain messages.
 */
export const formatLangChainMessages = (
  messages: Array<MessageInput>,
  formatOptions: Omit<FormatMessageParams, 'message' | 'langChain'>
): Array<
  | RoleBearingMessage<HumanMessage>
  | RoleBearingMessage<AIMessage>
  | RoleBearingMessage<SystemMessage>
> => {
  return messages.map((msg) => {
    const formatted = formatMessage({
      ...formatOptions,
      message: msg,
      langChain: true,
    });
    return formatted as
      | RoleBearingMessage<HumanMessage>
      | RoleBearingMessage<AIMessage>
      | RoleBearingMessage<SystemMessage>;
  });
};

interface LangChainMessage {
  lc_kwargs?: {
    additional_kwargs?: Record<string, any>;
    [key: string]: any;
  };
  kwargs?: {
    additional_kwargs?: Record<string, any>;
    [key: string]: any;
  };
  [key: string]: any;
}

/**
 * Formats a LangChain message object by merging properties from `lc_kwargs` or `kwargs` and `additional_kwargs`.
 *
 * @param message - The message object to format.
 * @returns - The formatted LangChain message.
 */
export const formatFromLangChain = (
  message: LangChainMessage
): Record<string, any> => {
  const kwargs = message.lc_kwargs ?? message.kwargs ?? {};
  const { additional_kwargs = {}, ...message_kwargs } = kwargs;
  return {
    ...message_kwargs,
    ...additional_kwargs,
  };
};

interface FormatAssistantMessageOptions {
  preserveUnpairedServerToolUses?: boolean;
  preserveReasoningContent?: boolean;
  provider?: Providers;
  sourceMessageId?: string;
}

interface FormatAgentMessagesOptions {
  provider?: Providers;
  /** Reconstruct hidden `reasoning_content` from `THINK` parts onto prior
   *  tool-call messages. Explicit opt-in for OpenAI-compatible endpoints that
   *  replay reasoning across turns; defaults to on for DeepSeek thinking-mode. */
  preserveReasoningContent?: boolean;
  /** Skill names already primed fresh this turn (manual/always-apply). Their
   *  historical `skill` tool_calls are not reconstructed into a HumanMessage,
   *  so the same SKILL.md body is not injected twice in one request. */
  skipSkillBodyNames?: Set<string>;
}

function extractReasoningContent(
  part: MessageContentComplex | undefined | null
): string {
  if (part == null || typeof part !== 'object') {
    return '';
  }
  if (part.type === ContentTypes.THINK) {
    const think = (part as ReasoningContentText).think;
    return typeof think === 'string' ? think : '';
  }
  if (part.type === ContentTypes.THINKING) {
    const thinking = (part as ThinkingContentText).thinking;
    return typeof thinking === 'string' ? thinking : '';
  }
  if (part.type === ContentTypes.REASONING) {
    const reasoning = (part as GoogleReasoningContentText).reasoning;
    return typeof reasoning === 'string' ? reasoning : '';
  }
  if (part.type === ContentTypes.REASONING_CONTENT) {
    const reasoningText = (part as BedrockReasoningContentText).reasoningText;
    return typeof reasoningText.text === 'string' ? reasoningText.text : '';
  }
  return '';
}

type ServerToolInput = Exclude<NonNullable<ToolCallPart['args']>, string>;

function parseServerToolInput(args: ToolCallPart['args']): ServerToolInput {
  if (typeof args === 'string') {
    try {
      const parsed = JSON.parse(args) as unknown;
      return parsed != null &&
        typeof parsed === 'object' &&
        !Array.isArray(parsed)
        ? (parsed as ServerToolInput)
        : {};
    } catch {
      return {};
    }
  }
  return args != null && typeof args === 'object' ? args : {};
}

function getTextContent(part: MessageContentComplex): string {
  const { text } = part as { text?: unknown };
  return typeof text === 'string' ? text : '';
}

function hasMeaningfulAssistantContent(part: MessageContentComplex): boolean {
  if (part.type === ContentTypes.TEXT) {
    return getTextContent(part).trim().length > 0;
  }
  if (
    part.type === ContentTypes.TOOL_CALL ||
    part.type === ContentTypes.ERROR ||
    part.type === ContentTypes.AGENT_UPDATE ||
    part.type === ContentTypes.SUMMARY ||
    part.type === ContentTypes.ACTIVITY_LABEL
  ) {
    return false;
  }
  if (
    part.type === ContentTypes.THINK ||
    part.type === ContentTypes.THINKING ||
    part.type === ContentTypes.REASONING ||
    part.type === ContentTypes.REASONING_CONTENT ||
    part.type === 'redacted_thinking'
  ) {
    return extractReasoningContent(part).trim().length > 0;
  }
  return part.type != null && part.type !== '';
}

function getToolUseId(part: MessageContentComplex): string | undefined {
  if (!('tool_use_id' in part) || typeof part.tool_use_id !== 'string') {
    return undefined;
  }
  return part.tool_use_id;
}

function isValidServerToolResult(part: MessageContentComplex): boolean {
  const toolUseId = getToolUseId(part);
  if (
    toolUseId?.startsWith(Constants.ANTHROPIC_SERVER_TOOL_PREFIX) !== true ||
    !('content' in part)
  ) {
    return false;
  }
  const { content } = part as { content?: unknown };
  return (
    Array.isArray(content) ||
    (content != null &&
      typeof content === 'object' &&
      'type' in content &&
      (content as { type?: unknown }).type === 'web_search_tool_result_error')
  );
}

function getToolCallId(part: MessageContentComplex): string | undefined {
  if (part.type !== ContentTypes.TOOL_CALL) {
    return undefined;
  }
  const id = part.tool_call?.id;
  return typeof id === 'string' && id !== '' ? id : undefined;
}

function hasToolCallOutput(part: MessageContentComplex): boolean {
  if (part.type !== ContentTypes.TOOL_CALL) {
    return false;
  }
  const output = part.tool_call?.output;
  return output != null && output !== '';
}

function formatToolCallOutput(
  output: ToolCallPart['output'] | undefined
): MessageContent {
  if (output == null) {
    return '';
  }
  return compactToolContent(output, HARD_MAX_TOOL_RESULT_CHARS).content;
}

/**
 * Content for the synthetic assistant turn that separates a trailing steer
 * from the next user turn. Non-empty by necessity — see the push site.
 */
const STEER_ANCHOR_PLACEHOLDER = '_';

/**
 * True when an assistant message replayed as a steer and nothing followed it,
 * so the emitted run ends on the steer's `HumanMessage`.
 */
function endsWithSteerMessage(
  formatted: Array<RoleBearingMessage<BaseMessage>>
): boolean {
  if (formatted.length === 0) {
    return false;
  }
  return formatted[formatted.length - 1].additional_kwargs.source === 'steer';
}

/**
 * Helper function to format an assistant message
 * @param message The message to format
 * @param options Optional formatting options
 * @returns Array of formatted messages
 */
function formatAssistantMessage(
  message: Partial<TMessage>,
  options?: FormatAssistantMessageOptions
): Array<
  | RoleBearingMessage<AIMessage>
  | RoleBearingMessage<ToolMessage>
  | RoleBearingMessage<HumanMessage>
> {
  const formattedMessages: Array<
    | RoleBearingMessage<AIMessage>
    | RoleBearingMessage<ToolMessage>
    | RoleBearingMessage<HumanMessage>
  > = [];
  const appendFormattedMessage = (
    formattedMessage: (typeof formattedMessages)[number]
  ): void => {
    stampSourceMessageIdentity(
      formattedMessage,
      options?.sourceMessageId,
      formattedMessages.length
    );
    formattedMessages.push(formattedMessage);
  };
  let currentContent: MessageContentComplex[] = [];
  let lastAIMessage: RoleBearingMessage<AIMessage> | null = null;
  let hasReasoning = false;
  let pendingReasoningContent = '';
  const emittedServerToolUseIds = new Set<string>();
  const pendingServerToolUses = new Map<string, MessageContentComplex>();
  const shouldPreserveReasoningContent =
    options?.preserveReasoningContent === true;
  const serverToolResultIds = new Set<string>();
  const preferredToolCallParts = new Map<string, MessageContentComplex>();

  const takePendingReasoningContent = (): string | undefined => {
    if (!shouldPreserveReasoningContent || !pendingReasoningContent) {
      return undefined;
    }
    const reasoningContent = pendingReasoningContent;
    pendingReasoningContent = '';
    return reasoningContent;
  };

  const createAIMessage = (
    content: MessageContent
  ): RoleBearingMessage<AIMessage> => {
    const reasoningContent = takePendingReasoningContent();
    return withMessageRole(
      new AIMessage({
        content,
        ...(reasoningContent != null && {
          additional_kwargs: { reasoning_content: reasoningContent },
        }),
      }),
      'assistant'
    );
  };

  const attachPendingReasoningContent = (aiMessage: AIMessage): void => {
    const reasoningContent = takePendingReasoningContent();
    if (reasoningContent == null) {
      return;
    }
    aiMessage.additional_kwargs.reasoning_content =
      typeof aiMessage.additional_kwargs.reasoning_content === 'string'
        ? `${aiMessage.additional_kwargs.reasoning_content}${reasoningContent}`
        : reasoningContent;
  };

  const flushPendingServerToolUse = (toolUseId: string): void => {
    for (const [id, content] of pendingServerToolUses) {
      pendingServerToolUses.delete(id);
      if (id === toolUseId) {
        currentContent.push(content);
        emittedServerToolUseIds.add(id);
        return;
      }
    }
  };

  if (Array.isArray(message.content)) {
    const contentParts = message.content as Array<
      MessageContentComplex | undefined | null
    >;

    for (const part of contentParts) {
      if (part == null) {
        continue;
      }
      if (isValidServerToolResult(part)) {
        serverToolResultIds.add(getToolUseId(part) ?? '');
      }
      if (options?.provider === Providers.ANTHROPIC) {
        const toolCallId = getToolCallId(part);
        if (toolCallId == null) {
          continue;
        }
        const preferredPart = preferredToolCallParts.get(toolCallId);
        if (
          preferredPart == null ||
          (!hasToolCallOutput(preferredPart) && hasToolCallOutput(part))
        ) {
          preferredToolCallParts.set(toolCallId, part);
        }
      }
    }

    for (const part of contentParts) {
      if (part == null) {
        continue;
      }
      const toolUseId = getToolUseId(part);
      if (toolUseId != null) {
        const isServerToolResult = isValidServerToolResult(part);
        if (
          toolUseId.startsWith(Constants.ANTHROPIC_SERVER_TOOL_PREFIX) &&
          !isServerToolResult
        ) {
          continue;
        }
        flushPendingServerToolUse(toolUseId);
        if (isServerToolResult) {
          currentContent.push(part);
          continue;
        }
      } else if (hasMeaningfulAssistantContent(part)) {
        for (const id of pendingServerToolUses.keys()) {
          if (!serverToolResultIds.has(id)) {
            pendingServerToolUses.delete(id);
          }
        }
      }
      if (part.type === ContentTypes.TEXT && part.tool_call_ids) {
        /*
        If there's pending content, it needs to be aggregated as a single string to prepare for tool calls.
        For Anthropic models, the "tool_calls" field on a message is only respected if content is a string.
        */
        if (currentContent.length > 0) {
          if (
            currentContent.some((content) => content.type !== ContentTypes.TEXT)
          ) {
            currentContent.push(part);
            lastAIMessage = createAIMessage(toLangChainContent(currentContent));
            appendFormattedMessage(lastAIMessage);
            currentContent = [];
            continue;
          }
          let content = currentContent.reduce((acc, curr) => {
            if (curr.type === ContentTypes.TEXT) {
              return `${acc}${getTextContent(curr)}\n`;
            }
            return acc;
          }, '');
          content = `${content}\n${getTextContent(part)}`.trim();
          lastAIMessage = createAIMessage(content);
          appendFormattedMessage(lastAIMessage);
          currentContent = [];
          continue;
        }
        // Create a new AIMessage with this text and prepare for tool calls
        lastAIMessage = createAIMessage(getTextContent(part));
        appendFormattedMessage(lastAIMessage);
      } else if (part.type === ContentTypes.TOOL_CALL) {
        // Skip malformed tool call entries without tool_call property
        if (part.tool_call == null) {
          continue;
        }
        const toolCallId = getToolCallId(part);
        if (
          options?.provider === Providers.ANTHROPIC &&
          toolCallId != null &&
          preferredToolCallParts.get(toolCallId) !== part
        ) {
          continue;
        }

        // Note: `tool_calls` list is defined when constructed by `AIMessage` class, and outputs should be excluded from it
        const {
          output,
          args: _args,
          ..._tool_call
        } = part.tool_call as ToolCallPart;

        // Skip invalid tool calls that have no name AND no output
        if (
          _tool_call.name == null ||
          (_tool_call.name === '' && (output == null || output === ''))
        ) {
          continue;
        }

        if (
          options?.provider === Providers.ANTHROPIC &&
          typeof _tool_call.id === 'string' &&
          _tool_call.id.startsWith(Constants.ANTHROPIC_SERVER_TOOL_PREFIX)
        ) {
          if (
            !serverToolResultIds.has(_tool_call.id) &&
            options.preserveUnpairedServerToolUses !== true
          ) {
            continue;
          }
          if (
            emittedServerToolUseIds.has(_tool_call.id) ||
            pendingServerToolUses.has(_tool_call.id)
          ) {
            continue;
          }
          pendingServerToolUses.set(_tool_call.id, {
            type: 'server_tool_use',
            id: _tool_call.id,
            name: _tool_call.name,
            input: parseServerToolInput(_args),
          } as MessageContentComplex);
          continue;
        }

        if (!lastAIMessage) {
          // "Heal" the payload by creating an AIMessage to precede the tool call
          lastAIMessage = createAIMessage('');
          appendFormattedMessage(lastAIMessage);
        } else {
          attachPendingReasoningContent(lastAIMessage);
        }

        const tool_call: ToolCallPart = _tool_call;
        // TODO: investigate; args as dictionary may need to be providers-or-tool-specific
        let args: any = _args;
        try {
          if (typeof _args === 'string') {
            args = JSON.parse(_args);
          }
        } catch {
          if (typeof _args === 'string') {
            args = { input: _args };
          }
        }

        tool_call.args = args;
        if (
          options?.provider === Providers.ANTHROPIC &&
          Array.isArray(lastAIMessage.content)
        ) {
          const content = lastAIMessage.content as MessageContentComplex[];
          content.push({
            type: 'tool_use',
            id: normalizeAnthropicToolCallId(tool_call.id ?? ''),
            name: tool_call.name,
            input: args,
          } as MessageContentComplex);
          lastAIMessage.content = content as MessageContent;
        } else {
          if (!lastAIMessage.tool_calls) {
            lastAIMessage.tool_calls = [];
          }
          lastAIMessage.tool_calls.push(tool_call as ToolCall);
        }

        appendFormattedMessage(
          withMessageRole(
            new ToolMessage({
              tool_call_id: tool_call.id ?? '',
              name: tool_call.name,
              content: formatToolCallOutput(output),
            }),
            'tool'
          )
        );
      } else if (
        part.type === ContentTypes.THINK ||
        part.type === ContentTypes.THINKING ||
        part.type === ContentTypes.REASONING ||
        part.type === ContentTypes.REASONING_CONTENT ||
        part.type === 'redacted_thinking'
      ) {
        hasReasoning = true;
        pendingReasoningContent += extractReasoningContent(part);
        continue;
      } else if (part.type === ContentTypes.STEER) {
        /*
        A mid-run steer: user speech persisted inline in the assistant message
        at the tool-batch boundary it was injected. Flush accumulated
        assistant content first so ordering is preserved, then replay the
        steer as a standalone user message — multimodal when the host stamped
        a pre-encoded `media` content array (attachment refs are re-encoded
        per turn host-side, like any other user media). `lastAIMessage` is
        reset AFTER the HumanMessage: a post-steer tool_call must mint a
        FRESH assistant anchor (the heal path) so its AIMessage lands after
        the user turn — attaching it to the pre-steer anchor would emit its
        ToolMessage after the HumanMessage while the call itself sat before
        it, an invalid provider ordering.
        */
        if (currentContent.length > 0) {
          if (
            currentContent.some((content) => content.type !== ContentTypes.TEXT)
          ) {
            lastAIMessage = createAIMessage(toLangChainContent(currentContent));
            appendFormattedMessage(lastAIMessage);
          } else {
            const flushed = currentContent
              .reduce((acc, curr) => `${acc}${getTextContent(curr)}\n`, '')
              .trim();
            if (flushed.length > 0) {
              lastAIMessage = createAIMessage(flushed);
              appendFormattedMessage(lastAIMessage);
            }
          }
          currentContent = [];
        } else if (shouldPreserveReasoningContent && pendingReasoningContent) {
          /**
           * Reasoning directly preceding a steer has no `currentContent`
           * flush to consume it and the anchor resets below — emit an anchor
           * AIMessage now (createAIMessage folds the pending reasoning into
           * `additional_kwargs.reasoning_content`) or the persisted
           * assistant reasoning silently vanishes on replay.
           */
          lastAIMessage = createAIMessage('');
          appendFormattedMessage(lastAIMessage);
        }
        const steerPart = part as {
          steer?: string;
          media?: MessageContentComplex[];
        };
        const steerContent =
          Array.isArray(steerPart.media) && steerPart.media.length > 0
            ? toLangChainContent(steerPart.media)
            : (steerPart.steer ?? '');
        appendFormattedMessage(
          withMessageRole(
            new HumanMessage({
              content: steerContent as MessageContent,
              additional_kwargs: { role: 'user', source: 'steer' },
            }),
            'user'
          )
        );
        lastAIMessage = null;
        /** The steer splits the assistant message: the post-steer segment
         *  starts with fresh reasoning state (pre-steer reasoning was either
         *  flushed above or intentionally dropped when not preserving). */
        hasReasoning = false;
        pendingReasoningContent = '';
      } else if (
        part.type === ContentTypes.ERROR ||
        part.type === ContentTypes.AGENT_UPDATE ||
        part.type === ContentTypes.SUMMARY ||
        part.type === ContentTypes.ACTIVITY_LABEL
      ) {
        continue;
      } else {
        if (part.type === ContentTypes.TEXT && !getTextContent(part).trim()) {
          continue;
        }
        currentContent.push(part);
      }
    }
    for (const content of pendingServerToolUses.values()) {
      currentContent.push(content);
    }
  }

  if (hasReasoning && currentContent.length > 0) {
    let content = '';
    for (const part of currentContent) {
      if (part.type !== ContentTypes.TEXT) {
        appendFormattedMessage(
          createAIMessage(toLangChainContent(currentContent))
        );
        return formattedMessages;
      }
      content += `${getTextContent(part)}\n`;
    }
    content = content.trim();

    if (content) {
      appendFormattedMessage(createAIMessage(content));
    }
  } else if (currentContent.length > 0) {
    appendFormattedMessage(createAIMessage(toLangChainContent(currentContent)));
  }

  return formattedMessages;
}

function getSourceMessageId(message: Partial<TMessage>): string | undefined {
  const candidate =
    (message as { messageId?: string }).messageId ??
    (message as { id?: string }).id;
  if (typeof candidate !== 'string') {
    return undefined;
  }
  const normalized = candidate.trim();
  return normalized.length > 0 ? normalized : undefined;
}

/**
 * Keeps the first formatted message backward-compatible with its persisted
 * source id and preserves source correlation on every derived message.
 * Derived ids remain unset so the reducer can assign collision-free identities
 * during its existing pass. This also prevents invented provider-shaped ids
 * from leaking into provider request payloads.
 */
function stampSourceMessageIdentity(
  message: RoleBearingMessage<BaseMessage>,
  sourceMessageId: string | undefined,
  derivedIndex = 0
): void {
  if (sourceMessageId == null) {
    return;
  }
  message.additional_kwargs.sourceMessageId = sourceMessageId;
  if (derivedIndex !== 0) {
    return;
  }
  message.id = sourceMessageId;
  message.lc_kwargs.id = sourceMessageId;
}

/**
 * Labels all agent content for parallel patterns (fan-out/fan-in)
 * Groups consecutive content by agent and wraps with clear labels
 */
function labelAllAgentContent(
  contentParts: MessageContentComplex[],
  agentIdMap: Record<number, string>,
  agentNames?: Record<string, string>
): MessageContentComplex[] {
  const result: MessageContentComplex[] = [];
  let currentAgentId: string | undefined;
  let agentContentBuffer: MessageContentComplex[] = [];

  const flushAgentBuffer = (): void => {
    if (agentContentBuffer.length === 0) {
      return;
    }

    if (currentAgentId != null && currentAgentId !== '') {
      const agentName = (agentNames?.[currentAgentId] ?? '') || currentAgentId;
      const formattedParts: string[] = [];

      formattedParts.push(`--- ${agentName} ---`);

      for (const part of agentContentBuffer) {
        if (part.type === ContentTypes.THINK) {
          const thinkContent = (part as ReasoningContentText).think || '';
          if (thinkContent) {
            formattedParts.push(
              `${agentName}: ${JSON.stringify({
                type: 'think',
                think: thinkContent,
              })}`
            );
          }
        } else if (part.type === ContentTypes.TEXT) {
          const textContent: string = part.text ?? '';
          if (textContent) {
            formattedParts.push(`${agentName}: ${textContent}`);
          }
        } else if (part.type === ContentTypes.TOOL_CALL) {
          formattedParts.push(
            `${agentName}: ${JSON.stringify({
              type: 'tool_call',
              tool_call: (part as ToolCallContent).tool_call,
            })}`
          );
        }
      }

      formattedParts.push(`--- End of ${agentName} ---`);

      // Create a single text content part with all agent content
      result.push({
        type: ContentTypes.TEXT,
        text: formattedParts.join('\n\n'),
      } as MessageContentComplex);
    } else {
      // No agent ID, pass through as-is
      result.push(...agentContentBuffer);
    }

    agentContentBuffer = [];
  };

  for (let i = 0; i < contentParts.length; i++) {
    const part = contentParts[i];
    /** UI-only progress headers are not agent content and must not disturb
     *  agent state: a label with no `agentIdMap` entry would otherwise read
     *  as an agent change and flush the buffer mid-agent, splitting one
     *  agent's contiguous content into two labeled blocks. Skipped before
     *  any state transition below (mirrors the transfer path). */
    if (part.type === ContentTypes.ACTIVITY_LABEL) {
      continue;
    }
    const agentId = agentIdMap[i];

    // If agent changed, flush previous buffer
    if (agentId !== currentAgentId && currentAgentId !== undefined) {
      flushAgentBuffer();
    }

    currentAgentId = agentId;
    if (part.type === ContentTypes.STEER) {
      /** User speech is never agent content — see the transfer path above. */
      flushAgentBuffer();
      result.push(part);
      continue;
    }
    agentContentBuffer.push(part);
  }

  // Flush any remaining content
  flushAgentBuffer();

  return result;
}

/**
 * Groups content parts by agent and formats them with agent labels
 * This preprocesses multi-agent content to prevent identity confusion
 *
 * @param contentParts - The content parts from a run
 * @param agentIdMap - Map of content part index to agent ID
 * @param agentNames - Optional map of agent ID to display name
 * @param options - Configuration options
 * @param options.labelNonTransferContent - If true, labels all agent transitions (for parallel patterns)
 * @returns Modified content parts with agent labels where appropriate
 */
export const labelContentByAgent = (
  contentParts: MessageContentComplex[],
  agentIdMap?: Record<number, string>,
  agentNames?: Record<string, string>,
  options?: { labelNonTransferContent?: boolean }
): MessageContentComplex[] => {
  if (!agentIdMap || Object.keys(agentIdMap).length === 0) {
    return contentParts;
  }

  // If labelNonTransferContent is true, use a different strategy for parallel patterns
  if (options?.labelNonTransferContent === true) {
    return labelAllAgentContent(contentParts, agentIdMap, agentNames);
  }

  const result: MessageContentComplex[] = [];
  let currentAgentId: string | undefined;
  let agentContentBuffer: MessageContentComplex[] = [];
  let transferToolCallIndex: number | undefined;
  let transferToolCallId: string | undefined;

  const flushAgentBuffer = (): void => {
    if (agentContentBuffer.length === 0) {
      return;
    }

    // If this is content from a transferred agent, format it specially
    if (
      currentAgentId != null &&
      currentAgentId !== '' &&
      transferToolCallIndex !== undefined
    ) {
      const agentName = (agentNames?.[currentAgentId] ?? '') || currentAgentId;
      const formattedParts: string[] = [];

      formattedParts.push(`--- Transfer to ${agentName} ---`);

      for (const part of agentContentBuffer) {
        if (part.type === ContentTypes.THINK) {
          formattedParts.push(
            `${agentName}: ${JSON.stringify({
              type: 'think',
              think: (part as ReasoningContentText).think,
            })}`
          );
        } else if ('text' in part && part.type === ContentTypes.TEXT) {
          const textContent: string = part.text ?? '';
          if (textContent) {
            formattedParts.push(
              `${agentName}: ${JSON.stringify({
                type: 'text',
                text: textContent,
              })}`
            );
          }
        } else if (part.type === ContentTypes.TOOL_CALL) {
          formattedParts.push(
            `${agentName}: ${JSON.stringify({
              type: 'tool_call',
              tool_call: (part as ToolCallContent).tool_call,
            })}`
          );
        }
      }

      formattedParts.push(`--- End of ${agentName} response ---`);

      // Find the tool call that triggered this transfer and update its output
      if (transferToolCallIndex < result.length) {
        const transferToolCall = result[transferToolCallIndex];
        if (
          transferToolCall.type === ContentTypes.TOOL_CALL &&
          transferToolCall.tool_call?.id === transferToolCallId
        ) {
          transferToolCall.tool_call.output = formattedParts.join('\n\n');
        }
      }
    } else {
      // Not from a transfer, add as-is
      result.push(...agentContentBuffer);
    }

    agentContentBuffer = [];
    transferToolCallIndex = undefined;
    transferToolCallId = undefined;
  };

  for (let i = 0; i < contentParts.length; i++) {
    const part = contentParts[i];
    /** UI-only progress headers are not agent content and must not disturb
     *  agent state: a label with no `agentIdMap` entry would otherwise look
     *  like an agent change, flushing the buffer and resetting an open
     *  transfer capture so the transferred agent's following chunks lose
     *  their frame. Skipped before any state transition below. */
    if (part.type === ContentTypes.ACTIVITY_LABEL) {
      continue;
    }
    const agentId = agentIdMap[i];

    // Check if this is a transfer tool call
    const isTransferTool =
      (part.type === ContentTypes.TOOL_CALL &&
        (part as ToolCallContent).tool_call?.name?.startsWith(
          'lc_transfer_to_'
        )) ??
      false;

    // If agent changed, flush previous buffer
    if (agentId !== currentAgentId && currentAgentId !== undefined) {
      flushAgentBuffer();
    }

    currentAgentId = agentId;

    if (isTransferTool) {
      // Flush any existing buffer first
      flushAgentBuffer();
      // Add the transfer tool call to result
      result.push(part);
      // Mark that the next agent's content should be captured
      transferToolCallIndex = result.length - 1;
      transferToolCallId = (part as ToolCallContent).tool_call?.id;
      currentAgentId = undefined; // Reset to capture the next agent
    } else if (part.type === ContentTypes.STEER) {
      /**
       * User speech is never agent content: flush the buffer in place and
       * pass the steer through verbatim so `formatAssistantMessage` replays
       * it as a user turn. Folding it into a labeled transfer summary would
       * both drop the user's words and misattribute them to the agent.
       * The steer also CLOSES any open transfer capture — `flushAgentBuffer`
       * no-ops on an empty buffer, and leaving the capture live would fold
       * post-steer agent content into the pre-steer transfer output,
       * replaying it BEFORE the user's redirect.
       */
      flushAgentBuffer();
      transferToolCallIndex = undefined;
      transferToolCallId = undefined;
      currentAgentId = undefined;
      result.push(part);
    } else {
      agentContentBuffer.push(part);
    }
  }

  flushAgentBuffer();

  return result;
};

/** Extracts tool names from a tool_search output JSON string. */
function extractToolNamesFromSearchOutput(output: string): string[] {
  try {
    const parsed: unknown = JSON.parse(output);
    if (
      typeof parsed === 'object' &&
      parsed !== null &&
      Array.isArray((parsed as Record<string, unknown>).tools)
    ) {
      return (
        (parsed as Record<string, unknown>).tools as Array<{ name?: string }>
      )
        .map((t) => t.name)
        .filter((name): name is string => typeof name === 'string');
    }
  } catch {
    /** Output may have warnings prepended, try to find JSON within it */
    const jsonMatch = output.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      try {
        const parsed: unknown = JSON.parse(jsonMatch[0]);
        if (
          typeof parsed === 'object' &&
          parsed !== null &&
          Array.isArray((parsed as Record<string, unknown>).tools)
        ) {
          return (
            (parsed as Record<string, unknown>).tools as Array<{
              name?: string;
            }>
          )
            .map((t) => t.name)
            .filter((name): name is string => typeof name === 'string');
        }
      } catch {
        /* ignore */
      }
    }
  }
  return [];
}

/**
 * How far back a persisted summary reaches.
 *
 * `coverage` is authoritative: the block named the first source message that
 * compaction retained, so `messageIndex` is exclusive — everything before it is
 * covered and it survives whole. `positional` is the legacy reading for blocks
 * written before coverage existed (or whose anchor is no longer in the payload)
 * — the block's own location is the boundary, which is why it cannot
 * distinguish a retained tail from covered history.
 */
type SummaryBoundary =
  | {
      mode: 'coverage';
      messageIndex: number;
      text: string;
      tokenCount: number;
    }
  | {
      mode: 'positional';
      messageIndex: number;
      contentIndex: number;
      text: string;
      tokenCount: number;
    };

type SummaryTokenAdjustment = {
  original: number;
  adjusted: number;
  remainingChars: number;
  totalChars: number;
};

type SummaryScan = {
  boundary?: SummaryBoundary;
};

function resolveCoverageIndex(
  coverage: SummaryCoverage | undefined,
  indexBySourceId: Map<string, number>,
  summaryMessageIndex: number
): number | undefined {
  /** Persisted JSON, so the declared string type is not a runtime guarantee. */
  if (typeof coverage?.retainedFromMessageId !== 'string') {
    return undefined;
  }
  const retainedFromMessageId = coverage.retainedFromMessageId.trim();
  if (retainedFromMessageId === '') {
    return undefined;
  }
  const retainedIndex = indexBySourceId.get(retainedFromMessageId);
  return retainedIndex != null && retainedIndex <= summaryMessageIndex
    ? retainedIndex
    : undefined;
}

function scanSummaryBlocks(payload: TPayload): SummaryScan {
  let boundary: SummaryBoundary | undefined;
  /** Filled as the scan advances, so a coverage lookup only ever resolves to a
   *  message already passed — no second pass over the payload. */
  const indexBySourceId = new Map<string, number>();

  for (let i = 0; i < payload.length; i++) {
    const message = payload[i];
    const sourceMessageId = getSourceMessageId(message);
    if (sourceMessageId != null) {
      indexBySourceId.set(sourceMessageId, i);
    }
    if (!Array.isArray(message.content)) {
      continue;
    }

    for (let j = 0; j < message.content.length; j++) {
      const part = message.content[j] as MessageContentComplex | undefined;
      if (part == null || part.type !== ContentTypes.SUMMARY) {
        continue;
      }

      const summaryPart = part as Partial<SummaryContentBlock> & {
        text?: string;
      };

      // Try content array first (new format), then direct text (legacy format)
      let summaryText = (summaryPart.content ?? [])
        .map((block) =>
          'text' in block ? (block as { text: string }).text : ''
        )
        .join('')
        .trim();

      // Fallback: legacy format where text was a direct field on the block
      if (summaryText.length === 0 && typeof summaryPart.text === 'string') {
        summaryText = summaryPart.text.trim();
      }

      if (summaryText.length === 0) {
        continue;
      }

      const tokenCount =
        typeof summaryPart.tokenCount === 'number' &&
        Number.isFinite(summaryPart.tokenCount)
          ? summaryPart.tokenCount
          : 0;

      const retainedIndex = resolveCoverageIndex(
        summaryPart.coverage,
        indexBySourceId,
        i
      );

      boundary =
        retainedIndex != null
          ? {
            mode: 'coverage',
            messageIndex: retainedIndex,
            text: summaryText,
            tokenCount,
          }
          : {
            mode: 'positional',
            messageIndex: i,
            contentIndex: j,
            text: summaryText,
            tokenCount,
          };
    }
  }

  return { boundary };
}

function applySummaryBoundary(
  message: Partial<TMessage>,
  messageIndex: number,
  summaryBoundary?: SummaryBoundary
): Partial<TMessage> | null {
  if (!summaryBoundary) {
    return message;
  }

  /** The boundary names the first retained message, so it is exclusive: that
   *  message and everything after it — the recency tail included — stays
   *  verbatim, and only genuinely covered history is dropped. Summary parts on
   *  surviving messages are filtered later by `formatAssistantMessage`. */
  if (summaryBoundary.mode === 'coverage') {
    return messageIndex < summaryBoundary.messageIndex ? null : message;
  }

  if (messageIndex < summaryBoundary.messageIndex) {
    return null;
  }

  if (
    messageIndex !== summaryBoundary.messageIndex ||
    !Array.isArray(message.content)
  ) {
    return message;
  }

  return {
    ...message,
    content: message.content.slice(summaryBoundary.contentIndex + 1),
  };
}

/**
 * Whether `formatAssistantMessage` filters this part out of the emitted message.
 * Such a part contributes no prompt tokens, so measuring it as zero characters
 * is accurate — it must not be mistaken for content the heuristic cannot see.
 */
function isDroppedByFormatting(
  part: MessageContentComplex | undefined
): boolean {
  if (part == null) {
    return true;
  }
  if (
    part.type === ContentTypes.SUMMARY ||
    part.type === ContentTypes.ERROR ||
    part.type === ContentTypes.AGENT_UPDATE ||
    part.type === ContentTypes.ACTIVITY_LABEL
  ) {
    return true;
  }
  return part.type === ContentTypes.TEXT && getTextContent(part).trim() === '';
}

function measureValueChars(value: unknown): number {
  if (typeof value === 'string') {
    return value.length;
  }
  if (value == null || typeof value !== 'object') {
    return 0;
  }
  const measured = serializeStructuredValueBounded(value, 0).originalChars;
  return measured === Number.MAX_SAFE_INTEGER
    ? HARD_MAX_TOOL_RESULT_CHARS
    : Math.min(measured, HARD_MAX_TOOL_RESULT_CHARS);
}

/**
 * Whether a retained part's whole prompt cost is the text the char heuristic
 * reads, making it safe to represent in a character ratio.
 *
 * An allowlist, not a denylist. Media, resources, and tool calls carry cost that
 * is unrelated to their serialized length — a short image URL nested in
 * `tool_call.output` stands in for a fixed four-figure media charge — and
 * rejecting those case by case has repeatedly missed a nesting level. Listing
 * the two shapes whose characters `contentPartCharLength` actually reads makes
 * every other shape, present or future, ineligible by default: the ratio is
 * skipped and the entry keeps its original count, which prunes early rather than
 * exceeding the window.
 */
function isCharRatioEligible(part: MessageContentComplex | undefined): boolean {
  if (part == null) {
    return false;
  }
  return part.type === ContentTypes.TEXT || part.type === ContentTypes.THINKING;
}

function contentPartCharLength(part: MessageContentComplex): number {
  const record = part as Record<string, unknown>;
  let len = 0;
  if (typeof record.text === 'string') {
    len += record.text.length;
  }
  if (typeof record.thinking === 'string') {
    len += record.thinking.length;
  }
  len += measureValueChars(record.input);
  /** Tool calls nest their payload a level down, so measuring only the
   *  top-level fields scores an entire tool turn as zero characters. */
  const { tool_call: toolCall } = record;
  if (toolCall != null && typeof toolCall === 'object') {
    const call = toolCall as Record<string, unknown>;
    len += measureValueChars(call.name);
    len += measureValueChars(call.args);
    len += measureValueChars(call.output);
  }
  return len;
}

/** Extracts the skillName from a skill tool_call's args (string or object). */
function extractSkillName(args: unknown): string | undefined {
  let parsed: Record<string, unknown> | undefined;
  if (typeof args === 'string') {
    try {
      parsed = JSON.parse(args) as Record<string, unknown>;
    } catch {
      /* malformed args — skip */
    }
  } else {
    parsed = args as Record<string, unknown> | undefined;
  }
  const name = parsed?.skillName;
  return typeof name === 'string' && name !== '' ? name : undefined;
}

/**
 * Formats an array of messages for LangChain, handling tool calls and creating ToolMessage instances.
 *
 * @param payload - The array of messages to format.
 * @param indexTokenCountMap - Optional map of message indices to token counts.
 * @param tools - Optional set of tool names that are allowed in the request.
 * @param skills - Optional map of skill name to body for reconstructing skill HumanMessages.
 * @param options - Optional formatting options (provider, skipSkillBodyNames).
 * @returns - Object containing formatted messages and updated indexTokenCountMap if provided.
 */
export const formatAgentMessages = (
  payload: TPayload,
  indexTokenCountMap?: Record<number, number | undefined>,
  tools?: Set<string>,
  /** Pre-resolved skill bodies keyed by skill name. When present, HumanMessages
   *  are reconstructed after skill ToolMessages to restore skill instructions
   *  that were only in LangGraph state during the original run. */
  skills?: Map<string, string>,
  options?: FormatAgentMessagesOptions
): {
  messages: Array<
    | RoleBearingMessage<HumanMessage>
    | RoleBearingMessage<AIMessage>
    | RoleBearingMessage<SystemMessage>
    | RoleBearingMessage<ToolMessage>
  >;
  indexTokenCountMap?: Record<number, number>;
  /** Cross-run summary extracted from the payload. Should be forwarded to the
   *  agent run so it can be included in the system message via AgentContext. */
  summary?: { text: string; tokenCount: number };
  /** When a positional summary boundary sliced content from a message, the token
   *  count was proportionally reduced. Returned so the caller can log it. */
  boundaryTokenAdjustment?: SummaryTokenAdjustment;
} => {
  const messages: Array<
    | RoleBearingMessage<HumanMessage>
    | RoleBearingMessage<AIMessage>
    | RoleBearingMessage<SystemMessage>
    | RoleBearingMessage<ToolMessage>
  > = [];
  /**
   * A steer ended the previous payload entry, so the next message emitted —
   * whichever entry finally produces one — must be separated from it by an
   * assistant turn. Held rather than emitted so an entry that produces
   * nothing cannot leave the anchor stranded as the final turn.
   */
  let pendingSteerAnchor = false;
  /**
   * Emits the deferred anchor ahead of `next` — the message about to be
   * pushed. When that message is itself an assistant turn, it already IS the
   * separation the anchor exists to synthesize, so the intent is simply
   * discharged: emitting the placeholder anyway would put two assistant turns
   * back to back, which strict-alternation providers can reject and nothing downstream
   * repairs (`coalesceAdjacentUserTurns` merges user turns only).
   */
  const flushSteerAnchor = (next: { role?: LangChainMessageRole }): void => {
    if (!pendingSteerAnchor) {
      return;
    }
    pendingSteerAnchor = false;
    if (next.role === 'assistant') {
      return;
    }
    messages.push(
      withMessageRole(
        new AIMessage({ content: STEER_ANCHOR_PLACEHOLDER }),
        'assistant'
      )
    );
  };
  // If indexTokenCountMap is provided, create a new map to track the updated indices
  const updatedIndexTokenCountMap: Record<number, number> = {};
  let boundaryTokenAdjustment: SummaryTokenAdjustment | undefined;
  // Keep track of the mapping from original payload indices to result indices
  const indexMapping: Record<number, number[] | undefined> = {};
  const { boundary: summaryBoundary } = scanSummaryBlocks(payload);

  // Summary metadata is returned to the caller so it can be forwarded to the
  // agent run and included in the single system message via AgentContext.
  // We intentionally do NOT create a SystemMessage here — that would conflict
  // with the agent's own system message (instructions + summary combined).

  /**
   * Create a mutable copy of the tools set that can be expanded dynamically.
   * When we encounter tool_search results, we add discovered tools to this set,
   * making their subsequent tool calls valid.
   */
  const discoveredTools = tools ? new Set(tools) : undefined;

  // Process messages with tool conversion if tools set is provided
  for (let i = 0; i < payload.length; i++) {
    const rawMessage = payload[i];
    const sourceMessageId = getSourceMessageId(rawMessage);
    let message = applySummaryBoundary(rawMessage, i, summaryBoundary);
    if (!message) {
      indexMapping[i] = [];
      continue;
    }

    // Q: Store the current length of messages to track where this payload message starts in the result?
    // const startIndex = messages.length;
    if (typeof message.content === 'string') {
      message = {
        ...message,
        content: [
          { type: ContentTypes.TEXT, [ContentTypes.TEXT]: message.content },
        ],
      };
    } else if (Array.isArray(message.content) && message.content.length === 0) {
      indexMapping[i] = [];
      continue;
    }

    if (message.role !== 'assistant') {
      const formattedMessage = formatMessage({
        message: message as MessageInput,
        langChain: true,
      }) as
        | RoleBearingMessage<HumanMessage>
        | RoleBearingMessage<AIMessage>
        | RoleBearingMessage<SystemMessage>;
      stampSourceMessageIdentity(formattedMessage, sourceMessageId);
      flushSteerAnchor(formattedMessage);
      messages.push(formattedMessage);

      // Update the index mapping for this message
      indexMapping[i] = [messages.length - 1];
      continue;
    }

    // For assistant messages, track the starting index before processing
    const startMessageIndex = messages.length;

    /**
     * If tools set is provided, process tool_calls:
     * - Keep valid tool_calls (tools in the set or dynamically discovered)
     * - Convert invalid tool_calls to string representation for context preservation
     * - Dynamically expand the set when tool_search results are encountered
     */
    let processedMessage = message;
    let pendingSkillNames: Set<string> | undefined;
    if (discoveredTools) {
      const content = message.content;
      if (content != null && Array.isArray(content)) {
        const filteredContent: typeof content = [];
        const invalidToolCallIds = new Set<string>();
        const invalidToolStrings: string[] = [];

        for (const part of content) {
          if (part.type !== ContentTypes.TOOL_CALL) {
            filteredContent.push(part);
            continue;
          }

          /** Skip malformed tool_call entries */
          if (
            part.tool_call == null ||
            part.tool_call.name == null ||
            part.tool_call.name === ''
          ) {
            if (
              typeof part.tool_call?.id === 'string' &&
              part.tool_call.id !== ''
            ) {
              invalidToolCallIds.add(part.tool_call.id);
            }
            continue;
          }

          const toolName = part.tool_call.name;

          /**
           * If this is a tool_search result with output, extract discovered tool names
           * and add them to the discoveredTools set for subsequent validation.
           */
          if (
            toolName === Constants.TOOL_SEARCH &&
            typeof part.tool_call.output === 'string' &&
            part.tool_call.output !== ''
          ) {
            const extracted = extractToolNamesFromSearchOutput(
              part.tool_call.output
            );
            for (const name of extracted) {
              discoveredTools.add(name);
            }
          }

          if (discoveredTools.has(toolName)) {
            filteredContent.push(part);
            if (
              toolName === Constants.SKILL_TOOL &&
              skills?.size != null &&
              skills.size > 0
            ) {
              const skillName = extractSkillName(part.tool_call.args) ?? '';
              if (skillName) {
                (pendingSkillNames ??= new Set()).add(skillName);
              }
            }
          } else {
            /** Invalid tool - convert to string for context preservation */
            if (
              typeof part.tool_call.id === 'string' &&
              part.tool_call.id !== ''
            ) {
              invalidToolCallIds.add(part.tool_call.id);
            }
            const output = part.tool_call.output ?? '';
            invalidToolStrings.push(`Tool: ${toolName}, ${output}`);
          }
        }

        /** Remove tool_call_ids references to invalid tools from text parts */
        if (invalidToolCallIds.size > 0) {
          for (const part of filteredContent) {
            if (
              part.type === ContentTypes.TEXT &&
              Array.isArray(part.tool_call_ids)
            ) {
              part.tool_call_ids = part.tool_call_ids.filter(
                (id: string) => !invalidToolCallIds.has(id)
              );
              if (part.tool_call_ids.length === 0) {
                delete part.tool_call_ids;
              }
            }
          }
        }

        /** Append invalid tool strings to the content for context preservation */
        if (invalidToolStrings.length > 0) {
          /** Find the last text part or create one */
          let lastTextPartIndex = -1;
          for (let j = filteredContent.length - 1; j >= 0; j--) {
            if (filteredContent[j].type === ContentTypes.TEXT) {
              lastTextPartIndex = j;
              break;
            }
          }

          const invalidToolText = invalidToolStrings.join('\n');
          if (lastTextPartIndex >= 0) {
            const lastTextPart = filteredContent[lastTextPartIndex] as {
              type: string;
              [ContentTypes.TEXT]?: string;
              text?: string;
            };
            const existingText =
              lastTextPart[ContentTypes.TEXT] ?? lastTextPart.text ?? '';
            filteredContent[lastTextPartIndex] = {
              ...lastTextPart,
              [ContentTypes.TEXT]: existingText
                ? `${existingText}\n${invalidToolText}`
                : invalidToolText,
            };
          } else {
            /** No text part exists, create one */
            filteredContent.push({
              type: ContentTypes.TEXT,
              [ContentTypes.TEXT]: invalidToolText,
            });
          }
        }

        /** Use filtered content if we made any changes */
        if (
          filteredContent.length !== content.length ||
          invalidToolStrings.length > 0
        ) {
          processedMessage = { ...message, content: filteredContent };
        }
      }
    }

    /** When tools filtering is off, still detect skill tool_calls for body reconstruction */
    if (!discoveredTools && skills?.size != null && skills.size > 0) {
      const content = processedMessage.content;
      if (Array.isArray(content)) {
        for (const part of content) {
          if (
            part.type !== ContentTypes.TOOL_CALL ||
            part.tool_call?.name !== Constants.SKILL_TOOL
          ) {
            continue;
          }
          const skillName = extractSkillName(part.tool_call.args) ?? '';
          if (skillName) {
            (pendingSkillNames ??= new Set()).add(skillName);
          }
        }
      }
    }

    const formattedMessages = formatAssistantMessage(processedMessage, {
      preserveUnpairedServerToolUses: i === payload.length - 1,
      preserveReasoningContent:
        options?.preserveReasoningContent ??
        options?.provider === Providers.DEEPSEEK,
      provider: options?.provider,
      sourceMessageId,
    });
    /**
     * A steer that ends an assistant message leaves the replay on a
     * `HumanMessage`. The next payload message is itself a user turn, so the
     * sequence would reach the provider as two adjacent user turns — rejected
     * by strict-alternation providers. Anchor it with a placeholder assistant
     * turn.
     *
     * The placeholder must be NON-EMPTY. A string-content assistant message
     * with no tool calls passes through `_convertMessagesToAnthropicPayload`
     * verbatim — the empty-text repair there only covers array content and
     * tool-call turns — so an empty anchor would reach Anthropic as
     * `{role: 'assistant', content: ''}` and trade one invalid sequence for
     * another. Same single-underscore convention the Anthropic converter
     * already uses when it has to synthesize a non-empty block.
     *
     * Deferred rather than decided by lookahead. `i < payload.length - 1` only
     * proves a later ENTRY exists, not that it EMITS: entries with empty
     * content, and entries dropped by `applySummaryBoundary`, are skipped
     * silently. A trailing steer followed only by those would get the anchor
     * as the FINAL turn — an assistant prefill with no request after it, which
     * the model may simply never answer. So the intent is recorded and flushed
     * only when a message actually follows.
     *
     * Pushed AFTER source identity stamping above, deliberately. The anchor is
     * synthetic rather than derived from the persisted assistant entry, so it
     * must not claim that entry's source metadata. Left unstamped, it reaches
     * the reducer with a null id and is assigned a fresh one.
     * `endsWithSteerMessage` reads only `additional_kwargs.source`, so the
     * deferral cannot change which messages get anchored.
     */
    /**
     * Guarded on emission: an assistant entry whose blocks all filtered away
     * emits nothing, and flushing for it would strand the anchor as the final
     * turn — the pending flag stays set for whichever entry emits next.
     */
    if (formattedMessages.length > 0) {
      flushSteerAnchor(formattedMessages[0]);
    }
    messages.push(...formattedMessages);
    if (endsWithSteerMessage(formattedMessages)) {
      pendingSteerAnchor = true;
    }

    // Capture index range BEFORE skill body injection so injected
    // HumanMessages are excluded from the assistant's token distribution.
    const endMessageIndex = messages.length;

    if (pendingSkillNames?.size != null && pendingSkillNames.size > 0) {
      const skipSkillBodyNames = options?.skipSkillBodyNames;
      for (const skillName of pendingSkillNames) {
        if (skipSkillBodyNames != null && skipSkillBodyNames.has(skillName)) {
          continue;
        }
        const body = skills?.get(skillName) ?? '';
        if (body) {
          messages.push(
            withMessageRole(
              new HumanMessage({
                content: body,
                additional_kwargs: {
                  role: 'user',
                  isMeta: true,
                  source: 'skill',
                  skillName,
                },
              }),
              'user'
            )
          );
        }
      }
    }

    const resultIndices = [];
    for (let j = startMessageIndex; j < endMessageIndex; j++) {
      resultIndices.push(j);
    }
    indexMapping[i] = resultIndices;
  }

  if (indexTokenCountMap) {
    for (
      let originalIndex = 0;
      originalIndex < payload.length;
      originalIndex++
    ) {
      const resultIndices = indexMapping[originalIndex] || [];
      let tokenCount = indexTokenCountMap[originalIndex];

      if (tokenCount === undefined) {
        continue;
      }

      /**
       * Coverage mode deliberately leaves the count alone, even though the entry
       * holding the block is charged for summary text that `formatAssistantMessage`
       * filters out and `summary.tokenCount` accounts separately.
       *
       * Discounting it needs the summary's cost in the same units as
       * `indexTokenCountMap`, and that figure is not obtainable here: this
       * function receives no tokenizer, and a count recorded at write time is in
       * the writing run's units — `Run.create` derives its counter from the model
       * in play, and a consumer may supply its own — so a conversation continued
       * on a different model would subtract across encodings. Attempts to proxy
       * it (character ratios, provider identity) all under-count some shape,
       * which risks an over-context request; over-counting merely prunes early.
       * Fixing it properly means passing the reader a tokenizer, which is a
       * consumer-facing change and out of scope here.
       */
      if (
        summaryBoundary?.mode === 'positional' &&
        originalIndex === summaryBoundary.messageIndex &&
        Array.isArray(payload[originalIndex].content)
      ) {
        const content = payload[originalIndex]
          .content as MessageContentComplex[];
        const { contentIndex } = summaryBoundary;
        if (contentIndex >= 0 && contentIndex < content.length - 1) {
          let totalCharLen = 0;
          let remainingCharLen = 0;
          /**
           * The ratio applies only when *every* part of the entry is one whose
           * token cost tracks its character length. A single ineligible part
           * cancels the discount, whichever side of the boundary it sits on.
           *
           * Both sides can break it, in opposite directions. A retained image has
           * its fixed cost scaled away, collapsing the entry. A removed base64
           * payload inflates the denominator — serializing to a huge length while
           * the counter charges a fixed estimate — dragging retained text below
           * its real cost. Either way the request can exceed the window.
           *
           * Telling a text-bearing tool payload from a media-bearing one means
           * recursing into arbitrary nested output, which has already missed a
           * level twice here. Cancelling instead keeps the original count: an
           * over-count that prunes early rather than overflowing. Entries of
           * plain text and reasoning — the common shape — still proportion.
           */
          let everyRetainedPartMeasurable = true;
          for (let p = 0; p < content.length; p++) {
            const part = content[p];
            const retained = p > contentIndex;

            if (isDroppedByFormatting(part)) {
              /** Removed summary text is real removed content: it is read as
               *  plain text and belongs in the denominator. */
              if (!retained && part.type === ContentTypes.SUMMARY) {
                totalCharLen += contentPartCharLength(part);
              }
              continue;
            }

            const charLen = contentPartCharLength(part);
            if (!isCharRatioEligible(part) || (retained && charLen === 0)) {
              everyRetainedPartMeasurable = false;
              break;
            }
            totalCharLen += charLen;
            if (retained) {
              remainingCharLen += charLen;
            }
          }
          if (totalCharLen > 0 && everyRetainedPartMeasurable) {
            const original = tokenCount;
            tokenCount = Math.max(
              1,
              Math.round(tokenCount * (remainingCharLen / totalCharLen))
            );
            boundaryTokenAdjustment = {
              original,
              adjusted: tokenCount,
              remainingChars: remainingCharLen,
              totalChars: totalCharLen,
            };
          }
        }
      }

      const msgCount = resultIndices.length;
      if (msgCount === 1) {
        updatedIndexTokenCountMap[resultIndices[0]] = tokenCount;
        continue;
      }

      if (msgCount < 2) {
        continue;
      }

      let totalLength = 0;
      const lastIdx = msgCount - 1;
      const lengths = new Array<number>(msgCount);
      for (let k = 0; k < msgCount; k++) {
        const msg = messages[resultIndices[k]];
        const { content } = msg;
        let len = 0;
        if (typeof content === 'string') {
          len = content.length;
        } else if (Array.isArray(content)) {
          for (const part of content as Array<
            Record<string, unknown> | string | undefined
          >) {
            if (typeof part === 'string') {
              len += part.length;
            } else if (part != null && typeof part === 'object') {
              const val = part.text ?? part.content;
              if (typeof val === 'string') {
                len += val.length;
              }
            }
          }
        }
        const toolCalls = (msg as AIMessage).tool_calls;
        if (Array.isArray(toolCalls)) {
          for (const tc of toolCalls as Array<Record<string, unknown>>) {
            if (typeof tc.name === 'string') {
              len += tc.name.length;
            }
            const { args } = tc;
            if (typeof args === 'string') {
              len += args.length;
            } else if (args != null) {
              const measured = serializeStructuredValueBounded(
                args,
                0
              ).originalChars;
              len +=
                measured === Number.MAX_SAFE_INTEGER
                  ? HARD_MAX_TOOL_RESULT_CHARS
                  : Math.min(measured, HARD_MAX_TOOL_RESULT_CHARS);
            }
          }
        }
        lengths[k] = len;
        totalLength += len;
      }

      if (totalLength === 0) {
        const countPerMessage = Math.floor(tokenCount / msgCount);
        for (let k = 0; k < lastIdx; k++) {
          updatedIndexTokenCountMap[resultIndices[k]] = countPerMessage;
        }
        updatedIndexTokenCountMap[resultIndices[lastIdx]] =
          tokenCount - countPerMessage * lastIdx;
      } else {
        let distributed = 0;
        for (let k = 0; k < lastIdx; k++) {
          const share = Math.floor((lengths[k] / totalLength) * tokenCount);
          updatedIndexTokenCountMap[resultIndices[k]] = share;
          distributed += share;
        }
        updatedIndexTokenCountMap[resultIndices[lastIdx]] =
          tokenCount - distributed;
      }
    }
  }

  return {
    messages,
    indexTokenCountMap: indexTokenCountMap
      ? updatedIndexTokenCountMap
      : undefined,
    summary: summaryBoundary
      ? { text: summaryBoundary.text, tokenCount: summaryBoundary.tokenCount }
      : undefined,
    boundaryTokenAdjustment,
  };
};

/**
 * Adds a value at key 0 for system messages and shifts all key indices by one in an indexTokenCountMap.
 * This is useful when adding a system message at the beginning of a conversation.
 *
 * @param indexTokenCountMap - The original map of message indices to token counts
 * @param instructionsTokenCount - The token count for the system message to add at index 0
 * @returns A new map with the system message at index 0 and all other indices shifted by 1
 */
export function shiftIndexTokenCountMap(
  indexTokenCountMap: Record<number, number>,
  instructionsTokenCount: number
): Record<number, number> {
  // Create a new map to avoid modifying the original
  const shiftedMap: Record<number, number> = {};
  shiftedMap[0] = instructionsTokenCount;

  // Shift all existing indices by 1
  for (const [indexStr, tokenCount] of Object.entries(indexTokenCountMap)) {
    const index = Number(indexStr);
    shiftedMap[index + 1] = tokenCount;
  }

  return shiftedMap;
}

/** Checks whether a BaseMessage is a tool-role message. */
const isToolMessage = (m: BaseMessage): boolean =>
  m instanceof ToolMessage || ('role' in m && (m as any).role === 'tool');

const PORTABLE_FOLDED_MEDIA_TYPES = new Set(['image', 'image_url']);
const MAX_FOLDED_BLOCK_CHARS = 8_000;
const MAX_FOLDED_CONTEXT_CHARS = HARD_MAX_TOOL_RESULT_CHARS;
const MAX_FOLDED_CONTEXT_WORK = 100_000;
const FOLDED_CONTEXT_TRUNCATION_NOTICE =
  '… [additional folded context omitted]';
const syntheticProviderContextMessages = new WeakSet<BaseMessage>();

type FoldContextBudget = {
  remainingChars: number;
  remainingWork: number;
  truncated: boolean;
};

function createFoldContextBudget(): FoldContextBudget {
  return {
    remainingChars: MAX_FOLDED_CONTEXT_CHARS,
    remainingWork: MAX_FOLDED_CONTEXT_WORK,
    truncated: false,
  };
}

function readFoldedDataProperty(value: unknown, key: string): unknown {
  if (value == null || typeof value !== 'object') {
    return undefined;
  }
  try {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    return descriptor != null && 'value' in descriptor
      ? descriptor.value
      : undefined;
  } catch {
    return undefined;
  }
}

/**
 * Adds one logical line without first concatenating caller-controlled strings.
 * The shared budget covers every synthetic message emitted by one transform,
 * so many individually bounded blocks cannot build an unbounded aggregate.
 */
function appendFoldedLine(
  textChunks: string[],
  budget: FoldContextBudget,
  pieces: readonly string[]
): boolean {
  if (budget.remainingChars <= 0) {
    budget.truncated = true;
    return false;
  }

  const separatorChars = textChunks.length > 0 ? 1 : 0;
  const available = budget.remainingChars - separatorChars;
  if (available <= 0) {
    budget.remainingChars = 0;
    budget.truncated = true;
    return false;
  }

  let totalChars = 0;
  for (const piece of pieces) {
    totalChars = Math.min(Number.MAX_SAFE_INTEGER, totalChars + piece.length);
  }
  if (totalChars <= available) {
    const line = pieces.join('');
    textChunks.push(line);
    budget.remainingChars -= separatorChars + line.length;
    return true;
  }

  const notice = FOLDED_CONTEXT_TRUNCATION_NOTICE.slice(0, available);
  let remainingHeadChars = Math.max(0, available - notice.length);
  const boundedPieces: string[] = [];
  for (const piece of pieces) {
    if (remainingHeadChars <= 0) {
      break;
    }
    const retained = piece.slice(0, remainingHeadChars);
    boundedPieces.push(retained);
    remainingHeadChars -= retained.length;
  }
  boundedPieces.push(notice);
  textChunks.push(boundedPieces.join(''));
  budget.remainingChars = 0;
  budget.truncated = true;
  return false;
}

function consumeFoldedWork(
  textChunks: string[],
  budget: FoldContextBudget
): boolean {
  if (budget.remainingChars <= 0) {
    return false;
  }
  if (budget.remainingWork-- > 0) {
    return true;
  }
  appendFoldedLine(textChunks, budget, [FOLDED_CONTEXT_TRUNCATION_NOTICE]);
  budget.remainingChars = 0;
  budget.truncated = true;
  return false;
}

function serializeFoldedValue(value: unknown): string {
  const compacted = compactToolContent(value, MAX_FOLDED_BLOCK_CHARS).content;
  return typeof compacted === 'string'
    ? compacted
    : serializeStructuredValueBounded(compacted, MAX_FOLDED_BLOCK_CHARS)
      .content;
}

function markSyntheticProviderContext<T extends BaseMessage>(message: T): T {
  syntheticProviderContextMessages.add(message);
  return message;
}

function appendSyntheticProviderContextMessage(
  result: BaseMessage[],
  parts: MessageContentComplex[]
): boolean {
  if (parts.length === 0) {
    return false;
  }
  result.push(
    markSyntheticProviderContext(
      withMessageRole(
        new HumanMessage({ content: toLangChainContent(parts) }),
        'user'
      )
    )
  );
  return true;
}

/**
 * Identifies provider-context placeholders created by this module without
 * trusting user-controlled content prefixes or leaking marker metadata onto
 * the provider wire.
 */
export function isSyntheticProviderContextMessage(
  message: BaseMessage
): boolean {
  return syntheticProviderContextMessages.has(message);
}

/** Flushes accumulated text chunks into `parts` as a single text block. */
function flushTextChunks(
  textChunks: string[],
  parts: MessageContentComplex[]
): void {
  if (textChunks.length === 0) {
    return;
  }
  parts.push({
    type: ContentTypes.TEXT,
    text: textChunks.join('\n'),
  } as MessageContentComplex);
  textChunks.length = 0;
}

/**
 * Appends a single message's content to the running `textChunks` / `parts`
 * accumulators. Portable image blocks are shallow-copied into `parts` so
 * binary data never becomes text tokens. Provider-specific media/resource
 * blocks are retained as bounded text so a folded cross-provider history
 * cannot contain an unsupported native block or JSON-expand without limit.
 *
 * When `content` is an array containing tool_use blocks, `tool_calls` is NOT
 * additionally serialized (avoiding double output).  `tool_calls` is used as
 * a fallback when `content` is a plain string or an array with no tool_use.
 */
function appendMessageContent(
  msg: BaseMessage,
  role: string,
  textChunks: string[],
  parts: MessageContentComplex[],
  budget: FoldContextBudget
): void {
  const { content } = msg;

  if (typeof content === 'string') {
    if (content && consumeFoldedWork(textChunks, budget)) {
      appendFoldedLine(textChunks, budget, [`${role}: `, content]);
    }
    appendToolCalls(msg, role, textChunks, budget);
    return;
  }

  if (!Array.isArray(content)) {
    appendToolCalls(msg, role, textChunks, budget);
    return;
  }

  let hasToolUseBlock = false;

  for (const block of content as ExtendedMessageContent[]) {
    if (!consumeFoldedWork(textChunks, budget)) {
      hasToolUseBlock = true;
      break;
    }
    const blockTypeValue = readFoldedDataProperty(block, 'type');
    const blockType =
      typeof blockTypeValue === 'string' ? blockTypeValue : undefined;

    if (
      blockType !== 'tool_use' &&
      blockType !== 'tool_call' &&
      blockType !== 'tool_result' &&
      isAtomicToolContentBlock(block)
    ) {
      if (PORTABLE_FOLDED_MEDIA_TYPES.has(blockType ?? '')) {
        const blockChars = getToolContentCharLength([block]);
        if (blockChars > budget.remainingChars) {
          appendFoldedLine(textChunks, budget, [
            `${role}: [${blockType ?? 'media'} omitted: folded context limit]`,
          ]);
          continue;
        }
        flushTextChunks(textChunks, parts);
        parts.push({ ...block } as MessageContentComplex);
        budget.remainingChars -= blockChars;
      } else {
        appendFoldedLine(textChunks, budget, [
          `${role}: [${blockType ?? 'media'}] `,
          serializeFoldedValue(block),
        ]);
      }
      continue;
    }

    if (blockType === 'tool_use') {
      hasToolUseBlock = true;
      const name = readFoldedDataProperty(block, 'name');
      const input = readFoldedDataProperty(block, 'input');
      appendFoldedLine(textChunks, budget, [
        `${role}: [tool_use] ${typeof name === 'string' ? name : ''} `,
        serializeFoldedValue(input ?? {}),
      ]);
      continue;
    }

    // A `tool_call` content block appears either as the v1 standard shape
    // (`{ name, args }` at top level, which `@langchain/aws` maps to a Converse
    // toolUse) or this repo's `ToolCallContent` (`{ tool_call: { name, args,
    // output } }`, from `convertMessagesToContent` / persisted history). Handle
    // both, and emit any embedded output, so the name/args/result survive.
    if (blockType === 'tool_call') {
      hasToolUseBlock = true;
      const nested = readFoldedDataProperty(block, 'tool_call');
      const nestedName = readFoldedDataProperty(nested, 'name');
      const topLevelName = readFoldedDataProperty(block, 'name');
      let name = '';
      if (typeof nestedName === 'string') {
        name = nestedName;
      } else if (typeof topLevelName === 'string') {
        name = topLevelName;
      }
      const nestedArgs = readFoldedDataProperty(nested, 'args');
      const topLevelArgs = readFoldedDataProperty(block, 'args');
      const rawArgs = nestedArgs ?? topLevelArgs ?? {};
      const argsText =
        typeof rawArgs === 'string' ? rawArgs : serializeFoldedValue(rawArgs);
      appendFoldedLine(textChunks, budget, [
        `${role}: [tool_use] ${name}${argsText ? ' ' : ''}`,
        argsText,
      ]);
      const output = readFoldedDataProperty(nested, 'output');
      if (output != null && output !== '') {
        appendFoldedLine(textChunks, budget, [
          'Tool: ',
          typeof output === 'string' ? output : serializeFoldedValue(output),
        ]);
      }
      continue;
    }

    // A `tool_result` content block (e.g. an AIMessage(tool_call) followed by a
    // user message carrying the result). Preserve nested image blocks as-is
    // instead of JSON-stringifying them through the generic fallback.
    if (blockType === 'tool_result') {
      hasToolUseBlock = true;
      const inner = readFoldedDataProperty(block, 'content') as
        | ToolResultContent['content']
        | undefined;
      if (typeof inner === 'string') {
        if (inner) {
          appendFoldedLine(textChunks, budget, [
            `${role}: [tool_result] `,
            inner,
          ]);
        }
      } else if (Array.isArray(inner)) {
        for (const innerBlock of inner as Array<
          string | ExtendedMessageContent
        >) {
          if (!consumeFoldedWork(textChunks, budget)) {
            break;
          }
          if (typeof innerBlock === 'string') {
            if (innerBlock) {
              appendFoldedLine(textChunks, budget, [
                `${role}: [tool_result] `,
                innerBlock,
              ]);
            }
          } else {
            const innerTypeValue = readFoldedDataProperty(innerBlock, 'type');
            const innerType =
              typeof innerTypeValue === 'string' ? innerTypeValue : undefined;
            if (
              isAtomicToolContentBlock(innerBlock) &&
              PORTABLE_FOLDED_MEDIA_TYPES.has(innerType ?? '')
            ) {
              const blockChars = getToolContentCharLength([innerBlock]);
              if (blockChars <= budget.remainingChars) {
                flushTextChunks(textChunks, parts);
                parts.push({ ...innerBlock } as MessageContentComplex);
                budget.remainingChars -= blockChars;
              } else {
                appendFoldedLine(textChunks, budget, [
                  `${role}: [${innerType ?? 'media'} omitted: folded context limit]`,
                ]);
              }
            } else {
              const textValue = readFoldedDataProperty(innerBlock, 'text');
              const inputValue = readFoldedDataProperty(innerBlock, 'input');
              const innerText = textValue ?? inputValue;
              appendFoldedLine(textChunks, budget, [
                `${role}: [tool_result] `,
                typeof innerText === 'string' && innerText
                  ? innerText
                  : serializeFoldedValue(innerBlock),
              ]);
            }
          }
        }
      } else if (inner != null) {
        appendFoldedLine(textChunks, budget, [
          `${role}: [tool_result] `,
          serializeFoldedValue(inner),
        ]);
      }
      continue;
    }

    const text =
      readFoldedDataProperty(block, 'text') ??
      readFoldedDataProperty(block, 'input');
    if (typeof text === 'string' && text) {
      appendFoldedLine(textChunks, budget, [`${role}: `, text]);
      continue;
    }

    // Fallback: serialize unrecognized block types to preserve context
    if (blockType != null && blockType !== '') {
      appendFoldedLine(textChunks, budget, [
        `${role}: [${blockType}] `,
        serializeFoldedValue(block),
      ]);
    }
  }

  // If content array had no tool_use blocks, fall back to tool_calls metadata
  // (handles edge case: empty content array with tool_calls populated)
  if (!hasToolUseBlock) {
    appendToolCalls(msg, role, textChunks, budget);
  }
}

function appendToolCalls(
  msg: BaseMessage,
  role: string,
  textChunks: string[],
  budget: FoldContextBudget
): void {
  if (role !== 'AI') {
    return;
  }
  const aiMsg = msg as AIMessage;
  if (aiMsg.tool_calls && aiMsg.tool_calls.length > 0) {
    for (const tc of aiMsg.tool_calls) {
      if (!consumeFoldedWork(textChunks, budget)) {
        break;
      }
      const name = readFoldedDataProperty(tc, 'name');
      const args = readFoldedDataProperty(tc, 'args');
      appendFoldedLine(textChunks, budget, [
        `AI: [tool_call] ${typeof name === 'string' ? name : ''}(`,
        serializeFoldedValue(args),
        ')',
      ]);
    }
    return;
  }
  // Fall back to raw provider tool calls kept only in additional_kwargs.
  const rawToolCalls = aiMsg.additional_kwargs.tool_calls;
  if (!Array.isArray(rawToolCalls)) {
    return;
  }
  for (const tc of rawToolCalls) {
    if (!consumeFoldedWork(textChunks, budget)) {
      break;
    }
    const fn = readFoldedDataProperty(tc, 'function');
    if (fn == null) {
      continue;
    }
    const name = readFoldedDataProperty(fn, 'name');
    const args = readFoldedDataProperty(fn, 'arguments');
    appendFoldedLine(textChunks, budget, [
      `AI: [tool_call] ${typeof name === 'string' ? name : ''}(`,
      typeof args === 'string' ? args : '',
      ')',
    ]);
  }
}

/**
 * Ensures compatibility when switching from a non-thinking agent to a thinking-enabled agent.
 * Converts AI messages with tool calls (that lack thinking/reasoning blocks) into buffer strings,
 * avoiding the thinking block signature requirement.
 *
 * Recognizes the following as valid thinking/reasoning blocks:
 * - ContentTypes.THINKING (Anthropic)
 * - ContentTypes.REASONING_CONTENT (Bedrock)
 * - ContentTypes.REASONING (VertexAI / Google)
 * - 'redacted_thinking'
 *
 * @param messages - Array of messages to process
 * @param provider - The provider being used (unused but kept for future compatibility)
 * @param config - Optional RunnableConfig for structured agent logging
 * @param runStartIndex - Index in `messages` where the CURRENT run's own
 *   appended AI/Tool messages begin (i.e. anything at this index or later
 *   was just produced by this run's own iterations, not historical
 *   context). When provided, AI messages at or after this index are
 *   never converted to `[Previous agent context]` placeholders — Claude
 *   can validly skip a thinking block before a tool_use (cf. PR #116),
 *   so the agent's own in-run iterations must not be misclassified as
 *   foreign history. Without the signal the function falls back to its
 *   prior heuristic (`chainHasThinkingBlock`), preserving backward
 *   compatibility for callers that don't yet pass the boundary.
 * @returns The messages array with tool sequences converted to buffer strings if necessary
 */
export function ensureThinkingBlockInMessages(
  messages: BaseMessage[],
  _provider: Providers,
  config?: RunnableConfig,
  runStartIndex?: number
): BaseMessage[] {
  if (messages.length === 0) {
    return messages;
  }

  // Find the last HumanMessage. Only the trailing sequence after it needs
  // validation — earlier messages are history already accepted by the provider.
  let lastHumanIndex = -1;
  for (let k = messages.length - 1; k >= 0; k--) {
    const m = messages[k];
    if (
      m instanceof HumanMessage ||
      ('role' in m && (m as any).role === 'user')
    ) {
      lastHumanIndex = k;
      break;
    }
  }

  if (lastHumanIndex === messages.length - 1) {
    return messages;
  }

  const result: BaseMessage[] =
    lastHumanIndex >= 0 ? messages.slice(0, lastHumanIndex + 1) : [];
  const foldBudget = createFoldContextBudget();
  let i = lastHumanIndex + 1;

  while (i < messages.length) {
    const msg = messages[i];
    /** Detect AI messages by instanceof OR by role, in case cache-control cloning
     produced a plain object that lost the LangChain prototype. */
    const isAI =
      msg instanceof AIMessage ||
      msg instanceof AIMessageChunk ||
      ('role' in msg && (msg as any).role === 'assistant');

    if (!isAI) {
      result.push(msg);
      i++;
      continue;
    }

    const aiMsg = msg as AIMessage | AIMessageChunk;
    const hasToolCalls = aiMsg.tool_calls && aiMsg.tool_calls.length > 0;
    const contentIsArray = Array.isArray(aiMsg.content);

    // Check if the message has tool calls or tool_use content
    let hasToolUse = hasToolCalls ?? false;
    let hasThinkingBlock = false;

    if (contentIsArray && aiMsg.content.length > 0) {
      for (const c of aiMsg.content as ExtendedMessageContent[]) {
        if (typeof c !== 'object') {
          continue;
        }
        const type = readFoldedDataProperty(c, 'type');
        if (type === 'tool_use') {
          hasToolUse = true;
        } else if (
          type === ContentTypes.THINKING ||
          type === ContentTypes.REASONING_CONTENT ||
          type === ContentTypes.REASONING ||
          type === 'redacted_thinking'
        ) {
          hasThinkingBlock = true;
        }
        if (hasToolUse && hasThinkingBlock) {
          break;
        }
      }
    }

    // Bedrock also stores reasoning in additional_kwargs (may not be in content array)
    if (
      !hasThinkingBlock &&
      aiMsg.additional_kwargs.reasoning_content != null
    ) {
      hasThinkingBlock = true;
    }

    // If message has tool use but no thinking block, check whether this is a
    // continuation of a thinking-enabled agent's chain before converting.
    // Bedrock reasoning models can produce multiple AI→Tool rounds after an
    // initial reasoning response: the first AI message has reasoning_content,
    // but follow-ups have content: "" with only tool_calls. These are the
    // same agent's turn and must NOT be converted to HumanMessages.
    if (hasToolUse && !hasThinkingBlock) {
      // Current-run boundary check: anything at or after `runStartIndex`
      // is the current run's own work — preserve it. Claude is allowed
      // to skip a thinking block before a tool_use (cf. PR #116 in the
      // agents repo), so the agent's own first-iteration AI message can
      // legitimately have tool_calls without reasoning. Converting it to
      // a `[Previous agent context]` placeholder pollutes the next
      // iteration's prompt — the LLM sees the placeholder, treats it as
      // suspicious injected content, ignores its own real prior tool
      // result, and re-runs the tool to verify (which then often fails
      // because subsequent calls land in fresh sandboxes without the
      // file). Skip the conversion when we know this is in-run.
      if (runStartIndex !== undefined && i >= runStartIndex) {
        result.push(msg);
        i++;
        continue;
      }

      // Walk backwards — if an earlier AI message in the same chain (before
      // the nearest HumanMessage) has a thinking/reasoning block, this is a
      // continuation of a thinking-enabled turn, not a non-thinking handoff.
      if (chainHasThinkingBlock(messages, i)) {
        result.push(msg);
        i++;
        continue;
      }

      // Build structured content in a single pass over the AI + following
      // ToolMessages — preserves image blocks as-is to avoid serializing
      // binary data as text (which caused 174× token amplification).
      const parts: MessageContentComplex[] = [];
      const textChunks: string[] = [];
      appendFoldedLine(textChunks, foldBudget, ['[Previous agent context]']);

      appendMessageContent(msg, 'AI', textChunks, parts, foldBudget);

      let j = i + 1;
      while (j < messages.length && isToolMessage(messages[j])) {
        appendMessageContent(
          messages[j],
          'Tool',
          textChunks,
          parts,
          foldBudget
        );
        j++;
      }

      flushTextChunks(textChunks, parts);
      if (appendSyntheticProviderContextMessage(result, parts)) {
        emitAgentLog(
          config,
          'warn',
          'format',
          'ensureThinkingBlockInMessages: injecting [Previous agent context] HumanMessage' +
            ` (${parts.length} msgs at index ${i}, no thinking block in chain)`
        );
      }
      i = j;
    } else {
      // Keep the message as is
      result.push(msg);
      i++;
    }
  }

  return result;
}

/** Whether a message carries tool content a tool-less agent cannot legally
 *  send. Covers every representation a provider converter will serialize back
 *  into a request: a ToolMessage, parsed `AIMessage.tool_calls`, raw
 *  `additional_kwargs.tool_calls` (OpenAI keeps calls here when the parsed
 *  array is empty), and `tool_use` / `tool_call` / `tool_result` content
 *  blocks (`@langchain/aws` and the Anthropic converter map these to Converse
 *  `toolUse` / `toolResult`). Missing the parent AI message is not just a
 *  passthrough: folding its ToolMessage alone would leave an orphan
 *  `assistant(tool_calls) -> user(...)` sequence. */
function messageHasToolContent(msg: BaseMessage): boolean {
  if (isToolMessage(msg)) {
    return true;
  }
  const aiMsg = msg as AIMessage;
  if (aiMsg.tool_calls != null && aiMsg.tool_calls.length > 0) {
    return true;
  }
  const rawToolCalls = aiMsg.additional_kwargs.tool_calls;
  if (Array.isArray(rawToolCalls) && rawToolCalls.length > 0) {
    return true;
  }
  if (Array.isArray(msg.content)) {
    for (const block of msg.content as ExtendedMessageContent[]) {
      const type = readFoldedDataProperty(block, 'type');
      if (
        typeof block === 'object' &&
        (type === 'tool_use' || type === 'tool_call' || type === 'tool_result')
      ) {
        return true;
      }
    }
  }
  return false;
}

/** Whether a message carries a tool RESULT: a ToolMessage, or a message whose
 *  content includes a `tool_result` block (the shape when a call/result pair is
 *  split as `AIMessage(tool_call)` + `HumanMessage(tool_result)`). Such a result
 *  belongs with the preceding tool call, so it is absorbed into the same fold
 *  and labelled as tool output. */
function isToolResultMessage(msg: BaseMessage): boolean {
  if (isToolMessage(msg)) {
    return true;
  }
  if (Array.isArray(msg.content)) {
    return (msg.content as ExtendedMessageContent[]).some(
      (block) =>
        typeof block === 'object' &&
        readFoldedDataProperty(block, 'type') === 'tool_result'
    );
  }
  return false;
}

/**
 * Folds tool_use / tool_result content into plain text for an agent that binds
 * no tools.
 *
 * In a multi-agent graph, a tool-less destination still inherits the prior
 * agent's conversation history, which can contain toolUse/toolResult blocks.
 * Because it binds no tools, the model is invoked with no tool schema — and
 * Bedrock's Converse API rejects any request that carries toolUse/toolResult
 * blocks without a top-level toolConfig ("The toolConfig field must be defined
 * when using toolUse and toolResult content blocks"). Adding a dummy toolConfig
 * is not an option: AWS requires at least one tool, and it would expose a
 * capability the destination was intentionally denied.
 *
 * Each tool-call turn plus its trailing tool results (ToolMessages or
 * `tool_result` content blocks) is collapsed into a single `[Previous tool
 * interaction]` HumanMessage that preserves the tool name, arguments and result
 * as text (image blocks are kept as-is). Runs in a single pass: non-tool
 * messages pass through, `result` is allocated lazily on the first fold, and the
 * original array is returned unchanged when it holds no tool content (the common
 * fresh-tool-less-agent case).
 */
export function foldToolBlocksForToollessAgent(
  messages: BaseMessage[],
  config?: RunnableConfig
): BaseMessage[] {
  let result: BaseMessage[] | null = null;
  let foldedCount = 0;
  const foldBudget = createFoldContextBudget();
  let i = 0;
  while (i < messages.length) {
    const msg = messages[i];
    if (!messageHasToolContent(msg)) {
      result?.push(msg);
      i++;
      continue;
    }

    /** First fold — copy the untouched prefix once, then append from here. */
    if (result === null) {
      result = messages.slice(0, i);
    }

    const parts: MessageContentComplex[] = [];
    const textChunks: string[] = [];
    appendFoldedLine(textChunks, foldBudget, ['[Previous tool interaction]']);
    appendMessageContent(
      msg,
      isToolResultMessage(msg) ? 'Tool' : 'AI',
      textChunks,
      parts,
      foldBudget
    );
    foldedCount++;

    let j = i + 1;
    while (j < messages.length && isToolResultMessage(messages[j])) {
      appendMessageContent(messages[j], 'Tool', textChunks, parts, foldBudget);
      foldedCount++;
      j++;
    }

    flushTextChunks(textChunks, parts);
    appendSyntheticProviderContextMessage(result, parts);
    i = j;
  }

  if (result === null) {
    return messages;
  }

  emitAgentLog(
    config,
    'warn',
    'format',
    `foldToolBlocksForToollessAgent: folded ${foldedCount} tool message(s) into text for a tool-less agent`
  );

  return result;
}

/**
 * Walks backwards from `currentIndex` through the message array to check
 * whether an earlier AI message in the same "chain" (no HumanMessage boundary)
 * contains a thinking/reasoning block.
 *
 * A "chain" is a contiguous sequence of AI + Tool messages with no intervening
 * HumanMessage. Bedrock reasoning models produce reasoning on the first AI
 * response, then issue follow-up tool calls with `content: ""` and no
 * reasoning block. These follow-ups are part of the same thinking-enabled
 * turn and should not be converted.
 */
function chainHasThinkingBlock(
  messages: BaseMessage[],
  currentIndex: number
): boolean {
  for (let k = currentIndex - 1; k >= 0; k--) {
    const prev = messages[k];

    // HumanMessage = turn boundary — stop searching
    if (
      prev instanceof HumanMessage ||
      ('role' in prev && (prev as any).role === 'user')
    ) {
      return false;
    }

    // Check AI messages for thinking/reasoning blocks
    const isPrevAI =
      prev instanceof AIMessage ||
      prev instanceof AIMessageChunk ||
      ('role' in prev && (prev as any).role === 'assistant');

    if (isPrevAI) {
      const prevAiMsg = prev as AIMessage | AIMessageChunk;

      if (Array.isArray(prevAiMsg.content) && prevAiMsg.content.length > 0) {
        const content = prevAiMsg.content as ExtendedMessageContent[];
        if (
          content.some(
            (c) =>
              typeof c === 'object' &&
              (c.type === ContentTypes.THINKING ||
                c.type === ContentTypes.REASONING_CONTENT ||
                c.type === ContentTypes.REASONING ||
                c.type === 'redacted_thinking')
          )
        ) {
          return true;
        }
      }

      // Bedrock also stores reasoning in additional_kwargs
      if (prevAiMsg.additional_kwargs.reasoning_content != null) {
        return true;
      }
    }

    // ToolMessages are part of the chain — keep walking back
  }

  return false;
}
